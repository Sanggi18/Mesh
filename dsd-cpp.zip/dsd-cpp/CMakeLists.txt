cmake_minimum_required(VERSION 3.16)
project(dsd-cpp CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Core library: no external dependencies, no JNI.
add_library(dsd STATIC
  dop_packer.cpp
  dsd_usb.cpp
  dsd_file.cpp
  dsd_to_pcm.cpp
)
target_include_directories(dsd PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})

# Android: JNI bindings as a separate shared library.
if(ANDROID)
  add_library(dsd-jni SHARED dsd_jni.cpp)
  target_link_libraries(dsd-jni PRIVATE dsd)
endif()

# Host unit tests (not built for Android targets).
option(DSD_BUILD_TESTS "Build host unit tests" ON)
if(DSD_BUILD_TESTS AND NOT ANDROID)
  add_executable(test_dsd tests/test_dsd.cpp dsd_jni.cpp)
  target_link_libraries(test_dsd PRIVATE dsd)
  enable_testing()
  add_test(NAME dsd-tests COMMAND test_dsd)
endif()
