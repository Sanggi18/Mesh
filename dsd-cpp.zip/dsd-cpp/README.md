# DSD C++ — DoP, Native DSD, DSF/DFF, DSD→PCM

Implementasi C++ clean-room buat playback DSD bit-perfect. Ditulis dari
spesifikasi publik + perilaku yang teramati, **bukan** copy-paste kode
dari proyek mana pun.

## Sumber

| Sumber | Yang dipakai |
|---|---|
| [decent-player `docs/libs/DSD_SUPPORT.md`](https://github.com/Ma145/decent-player/blob/v0.1.0-libs/docs/libs/DSD_SUPPORT.md) (MIT) | Spek DoP, tabel sample rate, layout native alt 4, nama fungsi wrapper |
| [Lark Audio 0.7.0 REA](../REA_LARK_DSD.md) | Logika yang terbukti jalan: urutan mode, framing DoP di packetizer, silence word `0x69696969`, FIR Kaiser 125 dB, prioritas laju PCM |
| dCS DoP spec | Marker `0x05`/`0xFA` selang-seling |
| Spek publik DSF / DSDIFF | Struktur header file |

## File

| File | Isi |
|---|---|
| `dsd_types.h` | Enum laju DSD, mode, tabel rate (DoP = DSD/16, native = DSD/32) |
| `dop_packer.h/.cpp` | `DoPPacker` (frame 24/32-bit, marker reset tiap stream) + `NativePacker` (verbatim 32-bit + silence `0x69696969`) |
| `dsd_usb.h/.cpp` | `findDsdAltSetting()` (scan deskriptor USB cari alt DSD), `decideMode()` (urutan Lark), `pickPcmTargetRate()`, `MicroframeSizer` (akumulasi fraksi byte/microframe) |
| `dsd_file.h/.cpp` | Parser header DSF + DSDIFF, tolak DST, semua read bounds-checked |
| `dsd_to_pcm.h/.cpp` | Konversi DSD→PCM: FIR windowed-sinc Kaiser (~125 dB), dither TPDF xorshift32, clamp + hitung clipping |
| `dsd_jni.h/.cpp` | C API polos + contoh JNI `nativePackDoP` (ganti `DSD_JNI_CLASS` sesuai file Kotlin lo) |
| `CMakeLists.txt` | Build `libdsd` statik; `libdsd-jni` kalau `ANDROID`; test host |
| `tests/test_dsd.cpp` | Unit test host (rate, DoP marker, native, mode, DSF/DSDIFF sintetis, alt setting, konversi) |

## Yang sudah diverifikasi

Test host di-compile + jalan di VM (`g++ -std=c++17`), semua lolos:
rate table, marker DoP `0x05`→`0xFA`, reset marker, packing native
little-endian, urutan mode, prioritas laju PCM, parse DSF/DSDIFF sintetis,
penolakan DST, deteksi alt 4, dan konversi DSD→PCM (data all-ones →
mendekati +32767, all-zeros → mendekati −32767).

```sh
cmake -S . -B build && cmake --build build && ./build/test_dsd
# ALL TESTS PASSED
```

## Yang BELUM / batasan (jujur)

- **Belum dites di HP + DAC beneran.** Logika sudah dites di host, tapi
  perilaku USB (alt setting, konfirmasi laju, URB isochronous) beda-beda
  per DAC dan per HP. Wajib dites dengan DAC yang mendukung DoP/native.
- `DsdToPcm` itu konvolusi langsung (bukan polyphase) — benar tapi lambat;
  buat produksi ganti inner loop dengan polyphase decimator.
- `findDsdAltSetting()` itu scan defensif, bukan parser UAC2 lengkap;
  layout deskriptor vendor aneh bisa lolos dari deteksi.
- Filter FIR di sini pakai tap hasil hitung sendiri (Kaiser, spek Lark),
  bukan koefisien Lark — koefisien per-fase Lark tidak berhasil dipulihkan
  dari binary.
- JNI `nativePackDoP` contoh memakai packer fresh per call; di produksi
  packer harus hidup sepanjang stream supaya marker terus selang-seling.

## Integrasi ke SRMusic Android

1. Copy folder ini ke `app/src/main/cpp/dsd/` (atau sebagai git submodule).
2. Tambah ke `CMakeLists.txt` project: `add_subdirectory(dsd)` lalu
   `target_link_libraries(<target> dsd)`.
3. Dari `UsbAudioSink` (Kotlin): deteksi DSD dari ExoPlayer `Format`
   (`audio/vnd.dsd`), pilih mode via `decideMode`, lalu:
   - DoP → `dsd_dop_pack24/32` → kirim sebagai PCM 24-bit ke USB driver.
   - Native → `dsd_native_pack` → tulis ke alt setting DSD.
   - Convert → `DsdToPcm` → kirim PCM biasa.
4. Parser `parseDsdFile` dipakai kalau ExoPlayer tidak mengekstrak raw DSD
   (butuh custom Extractor DSF/DFF — lihat rekomendasi doc decent-player).
