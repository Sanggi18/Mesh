// dop_packer.cpp — DoP and native DSD packing implementation.
#include "dop_packer.h"

namespace dsd {

size_t DoPPacker::pack24(const uint16_t* words, size_t frames, int channels,
                         uint8_t* out) {
  if (words == nullptr || out == nullptr || channels <= 0) return 0;
  size_t written = 0;
  for (size_t f = 0; f < frames; ++f) {
    const uint8_t marker = marker_;
    for (int c = 0; c < channels; ++c) {
      const uint16_t w = words[f * static_cast<size_t>(channels) + c];
      // 24-bit PCM sample value: [marker][dsd_hi][dsd_lo], little-endian.
      out[written++] = static_cast<uint8_t>(w & 0xFF);         // dsd_lo
      out[written++] = static_cast<uint8_t>((w >> 8) & 0xFF);  // dsd_hi
      out[written++] = marker;
    }
    // Marker alternates every frame (same marker for all channels in a frame).
    marker_ = (marker_ == 0x05) ? 0xFA : 0x05;
  }
  return written;
}

size_t DoPPacker::pack32(const uint16_t* words, size_t frames, int channels,
                         uint8_t* out) {
  if (words == nullptr || out == nullptr || channels <= 0) return 0;
  size_t written = 0;
  for (size_t f = 0; f < frames; ++f) {
    const uint8_t marker = marker_;
    for (int c = 0; c < channels; ++c) {
      const uint16_t w = words[f * static_cast<size_t>(channels) + c];
      // 32-bit PCM sample value: [marker][dsd_hi][dsd_lo][0x00],
      // little-endian (marker shifted 8 bits vs the 24-bit layout).
      out[written++] = 0x00;                                   // padding
      out[written++] = static_cast<uint8_t>(w & 0xFF);         // dsd_lo
      out[written++] = static_cast<uint8_t>((w >> 8) & 0xFF);  // dsd_hi
      out[written++] = marker;
    }
    marker_ = (marker_ == 0x05) ? 0xFA : 0x05;
  }
  return written;
}

size_t NativePacker::pack(const uint32_t* dwords, size_t frames, int channels,
                          uint8_t* out) {
  if (dwords == nullptr || out == nullptr || channels <= 0) return 0;
  size_t written = 0;
  for (size_t i = 0; i < frames * static_cast<size_t>(channels); ++i) {
    const uint32_t w = dwords[i];
    out[written++] = static_cast<uint8_t>(w & 0xFF);
    out[written++] = static_cast<uint8_t>((w >> 8) & 0xFF);
    out[written++] = static_cast<uint8_t>((w >> 16) & 0xFF);
    out[written++] = static_cast<uint8_t>((w >> 24) & 0xFF);
  }
  return written;
}

size_t NativePacker::fillSilence(uint32_t* out, size_t words) {
  if (out == nullptr) return 0;
  for (size_t i = 0; i < words; ++i) out[i] = kSilenceWord;
  return words;
}

}  // namespace dsd
