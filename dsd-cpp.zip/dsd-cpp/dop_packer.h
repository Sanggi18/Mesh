// dop_packer.h — DoP (DSD over PCM) and native DSD packing.
//
// DoP framing (dCS spec, decent-player DSD_SUPPORT.md, Lark REA):
//   24-bit PCM sample: [0x05/0xFA marker] [16-bit DSD data]
//   32-bit PCM sample: [0x05/0xFA marker] [16-bit DSD data] [8-bit padding]
//   - The marker byte alternates 0x05 / 0xFA every frame.
//   - The marker is reset at every stream start, so the first marker is 0x05.
//   - The 16-bit DSD word holds 2 DSD bytes; the first byte is the MSB.
//   - PCM is little-endian on the USB wire.
//
// Native DSD packing (Lark REA):
//   - 4 DSD bytes -> one 32-bit word, first byte = most significant bits.
//   - Sent verbatim to isochronous packets at DSD/32 words per second.
//   - Underrun is filled with the silence word 0x69696969.
#pragma once

#include <cstddef>
#include <cstdint>

#include "dsd_types.h"

namespace dsd {

// Build a 16-bit DSD word from 2 DSD bytes (first byte = MSB).
inline uint16_t makeDsdWord16(uint8_t first, uint8_t second) {
  return static_cast<uint16_t>((static_cast<uint16_t>(first) << 8) | second);
}

// Build a 32-bit DSD word from 4 DSD bytes (first byte = MSB).
inline uint32_t makeDsdWord32(uint8_t b0, uint8_t b1, uint8_t b2, uint8_t b3) {
  return (static_cast<uint32_t>(b0) << 24) |
         (static_cast<uint32_t>(b1) << 16) |
         (static_cast<uint32_t>(b2) << 8) | static_cast<uint32_t>(b3);
}

// Packs DSD words into DoP PCM frames.
class DoPPacker {
 public:
  DoPPacker() = default;

  // Call at every stream start. First marker after reset is 0x05.
  void reset() { marker_ = 0x05; }
  uint8_t currentMarker() const { return marker_; }

  // Packs `frames` x `channels` 16-bit DSD words into 24-bit PCM samples.
  // `words` is interleaved [frame][channel]; `out` receives little-endian
  // 24-bit samples: [dsd_lo][dsd_hi][marker] per sample.
  // Returns bytes written (= frames * channels * 3).
  size_t pack24(const uint16_t* words, size_t frames, int channels,
                uint8_t* out);

  // Same, but into 32-bit PCM samples: [0x00][dsd_lo][dsd_hi][marker].
  // Returns bytes written (= frames * channels * 4).
  size_t pack32(const uint16_t* words, size_t frames, int channels,
                uint8_t* out);

 private:
  uint8_t marker_ = 0x05;  // Alternates 0x05 / 0xFA per frame.
};

// Packs raw DSD into 32-bit words for native DSD transport.
class NativePacker {
 public:
  // Silence word used to fill underruns (Lark: 0x69696969).
  static constexpr uint32_t kSilenceWord = 0x69696969;

  // Verbatim copy: `dwords` interleaved [frame][channel] -> `out`
  // little-endian. Returns bytes written (= frames * channels * 4).
  static size_t pack(const uint32_t* dwords, size_t frames, int channels,
                     uint8_t* out);

  // Fills `words` 32-bit words with the silence word. Returns words filled.
  static size_t fillSilence(uint32_t* out, size_t words);
};

}  // namespace dsd
