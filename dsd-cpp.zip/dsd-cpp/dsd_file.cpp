// dsd_file.cpp — DSF and DSDIFF header parsing.
#include "dsd_file.h"

#include <cstring>

namespace dsd {
namespace {

bool hasBytes(const uint8_t* data, size_t length, size_t offset,
              size_t needed) {
  return data != nullptr && offset <= length && needed <= length - offset;
}

bool isId(const uint8_t* data, size_t offset, const char* id) {
  return std::memcmp(data + offset, id, 4) == 0;
}

uint32_t readU32Le(const uint8_t* p) {
  return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) |
         (static_cast<uint32_t>(p[2]) << 16) |
         (static_cast<uint32_t>(p[3]) << 24);
}

uint64_t readU64Le(const uint8_t* p) {
  return static_cast<uint64_t>(readU32Le(p)) |
         (static_cast<uint64_t>(readU32Le(p + 4)) << 32);
}

uint32_t readU32Be(const uint8_t* p) {
  return (static_cast<uint32_t>(p[0]) << 24) |
         (static_cast<uint32_t>(p[1]) << 16) |
         (static_cast<uint32_t>(p[2]) << 8) | static_cast<uint32_t>(p[3]);
}

uint64_t readU64Be(const uint8_t* p) {
  return (static_cast<uint64_t>(readU32Be(p)) << 32) | readU32Be(p + 4);
}

uint16_t readU16Be(const uint8_t* p) {
  return static_cast<uint16_t>((static_cast<uint16_t>(p[0]) << 8) | p[1]);
}

}  // namespace

bool isValidDsdRate(uint32_t rate) {
  uint32_t base = 2822400;
  for (int i = 0; i <= 5; ++i) {
    if (rate == base) return true;
    base *= 2;
  }
  return false;
}

bool parseDsf(const uint8_t* data, size_t length, DsdFileInfo& out) {
  // DSD chunk: "DSD " + u64le size (28) + u64le total size + u64le metadata.
  if (!hasBytes(data, length, 0, 28) || !isId(data, 0, "DSD ")) return false;
  if (readU64Le(data + 4) != 28) return false;

  // fmt chunk at offset 28: "fmt " + u64le size (52) + fields.
  // Layout: "fmt "(4) + size u64 (8) + version u32 + format id u32 +
  // channel type u32 + channels u32 + sample rate u32 + bits u32 +
  // sample count u64 + block size u32 + reserved u32.
  if (!hasBytes(data, length, 28, 52) || !isId(data, 28, "fmt ")) return false;
  if (readU64Le(data + 32) != 52) return false;
  const uint32_t formatVersion = readU32Le(data + 40);
  const uint32_t formatId = readU32Le(data + 44);  // 0 = raw DSD, 1 = DST.
  const uint32_t channelType = readU32Le(data + 48);
  const uint32_t channels = readU32Le(data + 52);
  const uint32_t sampleRate = readU32Le(data + 56);
  const uint32_t bitsPerSample = readU32Le(data + 60);
  const uint64_t sampleCount = readU64Le(data + 64);
  (void)channelType;  // Channel mapping (1 = mono, 2 = stereo, ...).
  if (formatVersion != 1) return false;
  if (formatId == 1) {  // DST-compressed: unsupported, reject like Lark.
    out = DsdFileInfo{};
    out.isDst = true;
    return false;
  }
  if (formatId != 0) return false;
  if (channels < 1 || channels > 8) return false;
  if (!isValidDsdRate(sampleRate)) return false;
  if (bitsPerSample != 1) return false;

  // data chunk right after fmt: "data" + u64le size + raw DSD bytes.
  if (!hasBytes(data, length, 80, 12) || !isId(data, 80, "data")) return false;
  const uint64_t dataSize = readU64Le(data + 84);
  if (!hasBytes(data, length, 92, static_cast<size_t>(dataSize)) &&
      dataSize > length - 92) {
    // Truncated file: still report the header if the claimed size is
    // impossible; callers must check dataSize against what they have.
    return false;
  }

  out = DsdFileInfo{};
  out.format = DsdFileInfo::Format::kDsf;
  out.channels = static_cast<int>(channels);
  out.sampleRate = sampleRate;
  out.bitsPerSample = 1;
  out.totalSamples = sampleCount;
  out.dataOffset = 92;
  out.dataSize = dataSize;
  return true;
}

bool parseDsdiff(const uint8_t* data, size_t length, DsdFileInfo& out) {
  // FRM8 chunk: "FRM8" + u64be size + "DSD " form type (16-byte header).
  if (!hasBytes(data, length, 0, 16) || !isId(data, 0, "FRM8") ||
      !isId(data, 12, "DSD ")) {
    return false;
  }

  uint32_t sampleRate = 0;
  int channels = 0;
  bool dst = false;
  uint64_t dataOffset = 0;
  uint64_t dataSize = 0;

  size_t pos = 16;
  while (hasBytes(data, length, pos, 12)) {
    const uint64_t chunkSize = readU64Be(data + pos + 4);
    const size_t payload = pos + 12;
    if (chunkSize > length - payload && chunkSize != 0) return false;
    const size_t chunkEnd = payload + static_cast<size_t>(chunkSize);

    if (isId(data, pos, "PROP")) {
      // PROP payload: "SND " + sub-chunks.
      if (!hasBytes(data, length, payload, 4) ||
          !isId(data, payload, "SND ")) {
        return false;
      }
      size_t sub = payload + 4;
      while (hasBytes(data, length, sub, 12)) {
        const uint64_t subSize = readU64Be(data + sub + 4);
        const size_t subPayload = sub + 12;
        if (subSize > length - subPayload) return false;
        if (isId(data, sub, "FS  ") && subSize >= 4) {
          sampleRate = readU32Be(data + subPayload);
        } else if (isId(data, sub, "CHNL") && subSize >= 2) {
          channels = readU16Be(data + subPayload);
        } else if (isId(data, sub, "CMPR") && subSize >= 4) {
          if (isId(data, subPayload, "DST ")) dst = true;
        }
        sub = subPayload + static_cast<size_t>(subSize);
      }
    } else if (isId(data, pos, "DSD ")) {
      dataOffset = payload;
      dataSize = chunkSize;
    }
    pos = chunkEnd;
  }

  if (dst) {
    out = DsdFileInfo{};
    out.isDst = true;
    return false;
  }
  if (channels < 1 || channels > 8) return false;
  if (!isValidDsdRate(sampleRate)) return false;
  if (dataSize == 0) return false;

  out = DsdFileInfo{};
  out.format = DsdFileInfo::Format::kDsdiff;
  out.channels = channels;
  out.sampleRate = sampleRate;
  out.bitsPerSample = 1;
  out.totalSamples = dataSize * 8 / static_cast<uint64_t>(channels);
  out.dataOffset = dataOffset;
  out.dataSize = dataSize;
  return true;
}

bool parseDsdFile(const uint8_t* data, size_t length, DsdFileInfo& out) {
  if (!hasBytes(data, length, 0, 4)) return false;
  if (isId(data, 0, "DSD ")) return parseDsf(data, length, out);
  if (isId(data, 0, "FRM8")) return parseDsdiff(data, length, out);
  return false;
}

}  // namespace dsd
