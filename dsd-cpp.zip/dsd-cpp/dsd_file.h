// dsd_file.h — DSF and DSDIFF (.dff) file parsing.
//
// Reads only the headers; returns where the raw DSD bitstream starts and
// how long it is. The DSD bytes themselves are NOT decoded here — they go
// straight to the DoP packer / native packer / PCM converter.
//
// Format references (public specs):
//   DSF: "DSD " chunk, "fmt " chunk (format ID 0 = raw DSD, 1 = DST),
//        "data" chunk. DSD bits are MSB-first, stored per channel.
//   DSDIFF: "FRM8" ... "DSD " container, "PROP"/"SND " chunks ("FS " sample
//        rate, "CHNL" channels, "CMPR" compression), "DSD " data chunk.
//        Chunk sizes are big-endian. DST-compressed files are rejected,
//        matching Lark Audio behaviour.
//
// All reads are bounds-checked; malformed files fail instead of crashing.
#pragma once

#include <cstddef>
#include <cstdint>

namespace dsd {

struct DsdFileInfo {
  enum class Format { kDsf, kDsdiff, kUnknown };

  Format format = Format::kUnknown;
  int channels = 0;             // 1..8 (passthrough only supports 1..2).
  uint32_t sampleRate = 0;      // e.g. 2822400 for DSD64.
  int bitsPerSample = 1;        // Always 1 for DSD.
  uint64_t totalSamples = 0;    // Samples per channel.
  uint64_t dataOffset = 0;      // Byte offset of the raw DSD bitstream.
  uint64_t dataSize = 0;        // Bytes of raw DSD bitstream.
  bool isDst = false;           // True when DST-compressed (unsupported).
};

// Parses a DSF header. Returns false on bad magic, DST, or truncation.
bool parseDsf(const uint8_t* data, size_t length, DsdFileInfo& out);

// Parses a DSDIFF (.dff) header. Returns false on bad magic, DST, or
// truncation.
bool parseDsdiff(const uint8_t* data, size_t length, DsdFileInfo& out);

// Sniffs the magic ("DSD " vs "FRM8") and dispatches. Rejects DST files.
bool parseDsdFile(const uint8_t* data, size_t length, DsdFileInfo& out);

// True when the rate is a valid DSD rate (2822400 * 2^n, n = 0..5).
bool isValidDsdRate(uint32_t rate);

}  // namespace dsd
