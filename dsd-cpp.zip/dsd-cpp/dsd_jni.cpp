// dsd_jni.cpp — Plain C API + example JNI bindings for the DSD code.
//
// The core (dop_packer / dsd_usb / dsd_file / dsd_to_pcm) has no JNI
// dependency. This file exposes a small C API any wrapper can call, plus
// one example JNI function (Android only) that packs DSD words into DoP
// frames from direct ByteBuffers.
//
// JNI class path: change DSD_JNI_CLASS below to match your Kotlin file
// (e.g. com/srmusic/playback/usb/UsbAudioStream for SRMusic Android).
// The example mirrors decent-player DSD_SUPPORT.md's
//   nativeUsbAudioWriteDsd(handle, dsdBuffer)
// naming; wiring it to an actual USB driver write is the integrator's job.
#include "dsd_jni.h"

#include <cstring>

#include "dop_packer.h"
#include "dsd_types.h"

namespace dsd {
namespace {

struct DopHandle {
  DoPPacker packer;
};

}  // namespace

extern "C" {

DsdDopPacker* dsd_dop_create(void) {
  return reinterpret_cast<DsdDopPacker*>(new DopHandle());
}

void dsd_dop_destroy(DsdDopPacker* handle) {
  delete reinterpret_cast<DopHandle*>(handle);
}

void dsd_dop_reset(DsdDopPacker* handle) {
  if (handle != nullptr) reinterpret_cast<DopHandle*>(handle)->packer.reset();
}

size_t dsd_dop_pack24(DsdDopPacker* handle, const uint16_t* words,
                      size_t frames, int channels, uint8_t* out) {
  if (handle == nullptr) return 0;
  return reinterpret_cast<DopHandle*>(handle)->packer.pack24(words, frames,
                                                             channels, out);
}

size_t dsd_dop_pack32(DsdDopPacker* handle, const uint16_t* words,
                      size_t frames, int channels, uint8_t* out) {
  if (handle == nullptr) return 0;
  return reinterpret_cast<DopHandle*>(handle)->packer.pack32(words, frames,
                                                             channels, out);
}

size_t dsd_native_pack(const uint32_t* dwords, size_t frames, int channels,
                       uint8_t* out) {
  return NativePacker::pack(dwords, frames, channels, out);
}

uint32_t dsd_dop_rate(uint32_t dsdRateHz) {
  switch (dsdRateHz) {
    case 2822400: return 176400;
    case 5644800: return 352800;
    case 11289600: return 705600;
    case 22579200: return 1411200;
    default: return 0;
  }
}

uint32_t dsd_native_rate(uint32_t dsdRateHz) { return dsdRateHz / 32; }

}  // extern "C"

#ifdef __ANDROID__
#include <jni.h>

// Change this to your Kotlin/Java class, e.g.:
//   com/srmusic/playback/usb/UsbAudioStream
#ifndef DSD_JNI_CLASS
#define DSD_JNI_CLASS com/srmusic/usb/DsdPacker
#endif

#define DSD_JNI_NAME_HELPER2(cls, name) Java_##cls##_##name
#define DSD_JNI_NAME_HELPER(cls, name) DSD_JNI_NAME_HELPER2(cls, name)
#define DSD_JNI_FN(name) DSD_JNI_NAME_HELPER(DSD_JNI_CLASS, name)

extern "C" {

// Packs DSD words from a direct ByteBuffer into DoP PCM frames in another
// direct ByteBuffer. `bits` is 24 or 32. Returns bytes written, or -1.
// Kotlin side:
//   private external fun nativePackDoP(dsd: ByteBuffer, out: ByteBuffer,
//                                      frames: Int, channels: Int,
//                                      bits: Int): Int
JNIEXPORT jint JNICALL DSD_JNI_FN(nativePackDoP)(
    JNIEnv* env, jclass /* clazz */, jobject dsdBuf, jobject outBuf,
    jint frames, jint channels, jint bits) {
  if (env == nullptr || dsdBuf == nullptr || outBuf == nullptr ||
      frames <= 0 || channels <= 0) {
    return -1;
  }
  auto* words = static_cast<uint16_t*>(env->GetDirectBufferAddress(dsdBuf));
  auto* out = static_cast<uint8_t*>(env->GetDirectBufferAddress(outBuf));
  if (words == nullptr || out == nullptr) return -1;
  // NOTE: a real engine keeps one DoPPacker per stream so the 0x05/0xFA
  // marker keeps alternating across calls. This example uses a fresh
  // packer per call (first marker 0x05); keep the packer in a long-lived
  // native object in production.
  DoPPacker packer;
  if (bits == 24) {
    return static_cast<jint>(
        packer.pack24(words, static_cast<size_t>(frames),
                      static_cast<int>(channels), out));
  } else if (bits == 32) {
    return static_cast<jint>(
        packer.pack32(words, static_cast<size_t>(frames),
                      static_cast<int>(channels), out));
  }
  return -1;
}

}  // extern "C"
#endif  // __ANDROID__

}  // namespace dsd
