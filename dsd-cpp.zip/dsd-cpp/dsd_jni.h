// dsd_jni.h — Plain C API for the DSD code (no JNI dependency).
#pragma once

#include <cstddef>
#include <cstdint>

#ifdef __cplusplus
extern "C" {
#endif

// Opaque DoP packer handle (keeps the 0x05/0xFA marker state per stream).
typedef struct DsdDopPacker DsdDopPacker;

DsdDopPacker* dsd_dop_create(void);
void dsd_dop_destroy(DsdDopPacker* handle);
// Resets the marker so the next packed frame starts with 0x05.
void dsd_dop_reset(DsdDopPacker* handle);
// Packs interleaved 16-bit DSD words [frame][channel] into DoP PCM.
// Returns bytes written (frames * channels * 3 for 24-bit, * 4 for 32-bit).
size_t dsd_dop_pack24(DsdDopPacker* handle, const uint16_t* words,
                      size_t frames, int channels, uint8_t* out);
size_t dsd_dop_pack32(DsdDopPacker* handle, const uint16_t* words,
                      size_t frames, int channels, uint8_t* out);
// Verbatim native-DSD packing of 32-bit words. Returns bytes written.
size_t dsd_native_pack(const uint32_t* dwords, size_t frames, int channels,
                       uint8_t* out);
// DoP PCM rate for a DSD rate in Hz (0 when DoP is not viable).
uint32_t dsd_dop_rate(uint32_t dsdRateHz);
// Native USB word rate for a DSD rate in Hz (DSD rate / 32).
uint32_t dsd_native_rate(uint32_t dsdRateHz);

#ifdef __cplusplus
}
#endif
