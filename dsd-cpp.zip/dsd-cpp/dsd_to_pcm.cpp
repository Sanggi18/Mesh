// dsd_to_pcm.cpp — DSD -> PCM conversion implementation.
#include "dsd_to_pcm.h"

#include <algorithm>
#include <cmath>
#include <vector>

namespace dsd {
namespace {

// Modified Bessel function I0(x), power-series form.
double besselI0(double x) {
  const double y = (x * x) / 4.0;
  double term = 1.0;
  double sum = 1.0;
  for (int k = 1; k < 40; ++k) {
    term *= y / (static_cast<double>(k) * static_cast<double>(k));
    sum += term;
    if (term < 1e-14) break;
  }
  return sum;
}

constexpr double kPi = 3.14159265358979323846;

}  // namespace

FilterSpec filterSpecForTarget(uint32_t targetRateHz) {
  switch (targetRateHz) {
    case 44100: return {20000, 22050};
    case 88200: return {30000, 44100};
    case 176400: return {40000, 66150};
    default: {
      const double t = static_cast<double>(targetRateHz);
      return {0.4535 * t, 0.5 * t};
    }
  }
}

bool DsdToPcm::init(DsdRate dsdRate, uint32_t targetRate, int bits) {
  if (bits != 16 && bits != 24) return false;
  const uint32_t dsdHz = dsdRateHz(dsdRate);
  if (targetRate == 0 || dsdHz % targetRate != 0) return false;
  const uint32_t ratio = dsdHz / targetRate;
  if (ratio < 8 || ratio > 128) return false;

  const FilterSpec spec = filterSpecForTarget(targetRate);
  const double cutoffNorm = ((spec.passHz + spec.stopHz) / 2.0) / dsdHz;
  // Kaiser beta for ~125 dB stopband attenuation (A > 50):
  // beta = 0.1102 * (A - 8.7).
  const double beta = 0.1102 * (125.0 - 8.7);
  // Tap count is a multiple of 8 (Lark), 8 taps per decimation step.
  const size_t taps = 8 * ratio;

  dsdRate_ = dsdRate;
  targetRate_ = targetRate;
  ratio_ = ratio;
  bits_ = bits;
  clipped_ = 0;
  buildFilter(cutoffNorm, beta, taps);
  return true;
}

void DsdToPcm::buildFilter(double cutoffNorm, double beta, size_t taps) {
  taps_.assign(taps, 0.0);
  const double m = static_cast<double>(taps - 1) / 2.0;
  const double i0Beta = besselI0(beta);
  double sum = 0.0;
  for (size_t n = 0; n < taps; ++n) {
    const double x = static_cast<double>(n) - m;
    double h;
    if (x == 0.0) {
      h = 2.0 * cutoffNorm;
    } else {
      h = std::sin(2.0 * kPi * cutoffNorm * x) / (kPi * x);
    }
    // Kaiser window.
    const double r = x / m;
    const double w =
        besselI0(beta * std::sqrt(std::max(0.0, 1.0 - r * r))) / i0Beta;
    taps_[n] = h * w;
    sum += taps_[n];
  }
  // Normalize to DC gain 1.0.
  for (double& t : taps_) t /= sum;
}

size_t DsdToPcm::convertChannel(const uint8_t* dsdBytes, size_t numBytes,
                                int32_t* out, size_t outCapacity) {
  if (dsdBytes == nullptr || out == nullptr || taps_.empty()) return 0;
  const size_t totalBits = numBytes * 8;
  const size_t outFrames = std::min(totalBits / ratio_, outCapacity);
  const size_t taps = taps_.size();
  const double half = static_cast<double>(taps - 1) / 2.0;
  const double maxVal = (bits_ == 16) ? 32767.0 : 8388607.0;
  const double minVal = (bits_ == 16) ? -32768.0 : -8388608.0;

  auto nextRandom = [this]() -> uint32_t {
    uint32_t x = rngState_;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rngState_ = x;
    return x;
  };
  // Uniform [0,1) from xorshift32.
  auto uniform01 = [&nextRandom]() -> double {
    return static_cast<double>(nextRandom()) / 4294967296.0;
  };

  for (size_t o = 0; o < outFrames; ++o) {
    // Center bit of this output sample's window.
    const int64_t center =
        static_cast<int64_t>(o * ratio_ + ratio_ / 2);
    double acc = 0.0;
    for (size_t i = 0; i < taps; ++i) {
      const int64_t bitPos =
          center - static_cast<int64_t>(half) + static_cast<int64_t>(i);
      double bit = 0.0;  // Out of range: silence (0), avoids edge DC.
      if (bitPos >= 0 && bitPos < static_cast<int64_t>(totalBits)) {
        const size_t byteIdx = static_cast<size_t>(bitPos) / 8;
        const int bitIdx = 7 - (static_cast<int>(bitPos) % 8);  // MSB-first.
        bit = ((dsdBytes[byteIdx] >> bitIdx) & 1) ? 1.0 : -1.0;
      }
      acc += taps_[i] * bit;
    }
    // TPDF dither: (u1 + u2 - 1) LSB, then quantize and clamp.
    const double dither = uniform01() + uniform01() - 1.0;
    double v = acc * maxVal + dither;
    if (v > maxVal) {
      v = maxVal;
      ++clipped_;
    } else if (v < minVal) {
      v = minVal;
      ++clipped_;
    }
    out[o] = static_cast<int32_t>(std::lround(v));
  }
  return outFrames;
}

}  // namespace dsd
