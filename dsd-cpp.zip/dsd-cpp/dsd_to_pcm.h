// dsd_to_pcm.h — DSD -> PCM conversion (fallback path).
//
// Used when the DAC supports neither native DSD nor DoP, when the user
// turns the DSD toggle off, when Enhanced DSP is active, or for >2 channels.
//
// Method (Lark Audio REA): linear-phase FIR low-pass, windowed-sinc with a
// Kaiser window, ~125 dB stopband attenuation, plus a half-band cascade in
// Lark's implementation. This file implements the FIR decimator directly
// (straight convolution, one channel at a time) as a correct reference —
// a production engine should replace the inner loop with a polyphase
// decimator. Quantization uses TPDF dither from a xorshift32 PRNG, then
// clamps (clipping is counted, like Lark).
//
// Filter specs (Lark): passband/stopband 20k/22.05k (-> 44.1k),
// 30k/44.1k (-> 88.2k), 40k/66.15k (-> 176.4k). Other target rates use
// passband 0.4535x and stopband 0.5x the target rate.
#pragma once

#include <cstddef>
#include <cstdint>
#include <vector>

#include "dsd_types.h"

namespace dsd {

struct FilterSpec {
  double passHz = 0;
  double stopHz = 0;
};

// Passband/stopband for a PCM target rate (see header comment).
FilterSpec filterSpecForTarget(uint32_t targetRateHz);

class DsdToPcm {
 public:
  DsdToPcm() = default;

  // targetRate must divide the DSD rate evenly (ratio 16/32/64/...).
  // bits must be 16 or 24. Returns false on bad parameters.
  bool init(DsdRate dsdRate, uint32_t targetRate, int bits);

  uint32_t ratio() const { return ratio_; }
  size_t numTaps() const { return taps_.size(); }
  int bits() const { return bits_; }
  uint64_t clippedSamples() const { return clipped_; }

  // Converts ONE channel. dsdBytes holds MSB-first DSD bits.
  // out receives int32 PCM samples already scaled to the `bits` range.
  // Returns the number of output samples written (<= outCapacity).
  size_t convertChannel(const uint8_t* dsdBytes, size_t numBytes,
                        int32_t* out, size_t outCapacity);

 private:
  void buildFilter(double cutoffNorm, double beta, size_t taps);

  DsdRate dsdRate_ = DsdRate::kDsd64;
  uint32_t targetRate_ = 0;
  uint32_t ratio_ = 0;
  int bits_ = 16;
  std::vector<double> taps_;
  uint32_t rngState_ = 0x12345678;  // xorshift32 state for TPDF dither.
  uint64_t clipped_ = 0;
};

}  // namespace dsd
