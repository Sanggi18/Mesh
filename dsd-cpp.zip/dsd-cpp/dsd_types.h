// dsd_types.h — Shared types and rate tables for DSD playback.
//
// Sources (clean-room, written from specs + observed behaviour):
//   - decent-player docs/libs/DSD_SUPPORT.md (Ma145/decent-player, MIT):
//     DoP framing, DSD sample-rate table, native alt-4 layout.
//   - Lark Audio 0.7.0 REA findings (~/workspace/lark-audio-rea/REA_LARK_DSD.md):
//     DSD/32 native rate, DSD/16 DoP rate, silence word 0x69696969,
//     target-rate priority for DSD->PCM conversion.
//   - dCS DoP specification (marker bytes 0x05/0xFA).
//
// No code is copied from either project. This is an original implementation.
#pragma once

#include <cstddef>
#include <cstdint>

namespace dsd {

// DSD sample rates: base 2.8224 MHz (64x 44.1 kHz), powers of two.
enum class DsdRate : uint32_t {
  kDsd64 = 2822400,
  kDsd128 = 5644800,
  kDsd256 = 11289600,
  kDsd512 = 22579200,
  kDsd1024 = 45158400,
  kDsd2048 = 90316800,
};

enum class DsdMode {
  kNative,       // Raw DSD bitstream over a dedicated USB alt setting.
  kDoP,          // DSD over PCM: DSD bits packed into PCM frames + markers.
  kConvertToPcm  // DSD decoded to PCM (FIR decimation) and sent as PCM.
};

inline uint32_t dsdRateHz(DsdRate rate) {
  return static_cast<uint32_t>(rate);
}

inline const char* dsdRateName(DsdRate rate) {
  switch (rate) {
    case DsdRate::kDsd64: return "DSD64";
    case DsdRate::kDsd128: return "DSD128";
    case DsdRate::kDsd256: return "DSD256";
    case DsdRate::kDsd512: return "DSD512";
    case DsdRate::kDsd1024: return "DSD1024";
    case DsdRate::kDsd2048: return "DSD2048";
  }
  return "DSD?";
}

// DoP PCM rate = DSD rate / 16 (16 DSD bits per PCM sample per channel).
// DSD1024+ would need >= 2.8224 MHz PCM, beyond practical DoP limits.
inline uint32_t dopPcmRateHz(DsdRate rate) {
  switch (rate) {
    case DsdRate::kDsd64: return 176400;
    case DsdRate::kDsd128: return 352800;
    case DsdRate::kDsd256: return 705600;
    case DsdRate::kDsd512: return 1411200;
    default: return 0;  // DSD1024/2048: DoP not viable.
  }
}

inline bool dopFeasible(DsdRate rate) { return dopPcmRateHz(rate) != 0; }

// Native USB rate = DSD rate / 32 (4 DSD bytes packed into one 32-bit word).
// Matches Lark's DsdDecoder: DSD64 -> 88.2 kHz word rate.
inline uint32_t nativeUsbRateHz(DsdRate rate) {
  return dsdRateHz(rate) / 32;
}

// Raw DSD bytes per second, per channel: 1 bit per sample.
inline uint32_t bytesPerSecondNative(DsdRate rate, int channels) {
  return (dsdRateHz(rate) / 8) * static_cast<uint32_t>(channels);
}

// Target PCM rates for DSD->PCM conversion, in priority order
// (Lark Audio: 176.4k -> 88.2k -> 192k -> 96k -> 44.1k -> 48k).
inline constexpr uint32_t kPcmTargetRatePriority[] = {176400, 88200, 192000,
                                                      96000, 44100, 48000};

}  // namespace dsd
