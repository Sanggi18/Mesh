// dsd_usb.cpp — USB-side DSD helpers implementation.
#include "dsd_usb.h"

namespace dsd {

// USB descriptor type codes we care about.
namespace {
constexpr uint8_t kDescInterface = 0x04;      // INTERFACE descriptor.
constexpr uint8_t kDescCsInterface = 0x24;    // Class-specific INTERFACE.
constexpr uint8_t kCsSubFormatType = 0x02;    // FORMAT_TYPE subtype.
constexpr uint8_t kAudioClass = 0x01;         // USB Audio.
constexpr uint8_t kAudioStreamingSubclass = 0x02;
constexpr uint8_t kFormatTypeIv = 0x04;  // UAC2 FORMAT_TYPE_IV (DSD).
}  // namespace

std::optional<DsdAltSetting> findDsdAltSetting(const uint8_t* descriptors,
                                               size_t length) {
  if (descriptors == nullptr || length < 9) return std::nullopt;

  std::optional<DsdAltSetting> heuristic;  // subslot 4 + res 32, any type.
  size_t pos = 0;
  int currentAlt = -1;
  bool inAudioStreaming = false;

  while (pos + 2 <= length) {
    const uint8_t descLen = descriptors[pos];
    const uint8_t descType = descriptors[pos + 1];
    if (descLen < 2 || pos + descLen > length) break;  // Malformed: stop.

    if (descType == kDescInterface && descLen >= 9) {
      // bInterfaceClass @5, bInterfaceSubClass @6, bAlternateSetting @3.
      inAudioStreaming =
          descriptors[pos + 5] == kAudioClass &&
          descriptors[pos + 6] == kAudioStreamingSubclass;
      currentAlt = inAudioStreaming ? descriptors[pos + 3] : -1;
    } else if (inAudioStreaming && currentAlt >= 0 &&
               descType == kDescCsInterface && descLen >= 8 &&
               descriptors[pos + 2] == kCsSubFormatType) {
      // FORMAT_TYPE descriptor: bFormatType @3, bSubslotSize @4,
      // bBitResolution @5.
      const int formatType = descriptors[pos + 3];
      const int subslotSize = descriptors[pos + 4];
      const int bitResolution = descriptors[pos + 5];
      if (subslotSize == 4 && bitResolution == 32) {
        DsdAltSetting found{currentAlt, subslotSize, bitResolution,
                            formatType};
        if (formatType == kFormatTypeIv) return found;  // Exact match.
        if (!heuristic.has_value()) heuristic = found;  // Vendor layout.
      }
    }
    pos += descLen;
  }
  return heuristic;
}

DsdMode decideMode(bool dsdDopEnabled, bool enhancedDsp, int channels,
                   bool hasNativeAlt, bool nativeRateOk, bool dopOk) {
  if (!dsdDopEnabled) return DsdMode::kConvertToPcm;
  if (enhancedDsp) return DsdMode::kConvertToPcm;
  if (channels < 1 || channels > 2) return DsdMode::kConvertToPcm;
  if (hasNativeAlt && nativeRateOk) return DsdMode::kNative;
  if (dopOk) return DsdMode::kDoP;
  return DsdMode::kConvertToPcm;
}

uint32_t pickPcmTargetRate(const uint32_t* dacRates, size_t count) {
  if (dacRates == nullptr) return 0;
  for (uint32_t wanted : kPcmTargetRatePriority) {
    for (size_t i = 0; i < count; ++i) {
      if (dacRates[i] == wanted) return wanted;
    }
  }
  return 0;
}

}  // namespace dsd
