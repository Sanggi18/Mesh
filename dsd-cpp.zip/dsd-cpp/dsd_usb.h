// dsd_usb.h — USB-side DSD helpers: alt-setting detection, isochronous
// packet sizing, mode decision, PCM target-rate selection.
//
// Sources: decent-player DSD_SUPPORT.md (alt 4, subslotSize=4,
// bitResolution=32, packet sizes from DSD rate / 8000 microframes) and
// Lark Audio 0.7.0 REA (mode-decision order, rate confirmation against the
// DAC, target-rate priority). Clean-room implementation, no copied code.
#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>

#include "dsd_types.h"

namespace dsd {

// A USB Audio Class 2.0 alternate setting that can carry raw DSD.
struct DsdAltSetting {
  int altSetting = -1;     // bAlternateSetting, e.g. 4 on Cayin RU7.
  int subslotSize = 0;     // Bytes per subslot, 4 for DSD native.
  int bitResolution = 0;   // Bits per sample, 32 for DSD native.
  int formatType = 0;      // UAC2 format type (IV = 4 for DSD, or vendor).
};

// Scans a raw USB configuration descriptor blob for an Audio Streaming
// interface alt setting that can carry native DSD. Prefers an alt setting
// whose format-type descriptor says FORMAT_TYPE_IV with subslotSize == 4
// and bitResolution == 32; falls back to any alt setting with
// subslotSize == 4 and bitResolution == 32 (vendor-specific layouts).
// Returns nullopt when no DSD-capable alt setting is found.
// NOTE: descriptor layouts vary by vendor; this is a defensive best-effort
// scan, not a full UAC2 parser.
std::optional<DsdAltSetting> findDsdAltSetting(const uint8_t* descriptors,
                                               size_t length);

// Bytes of native DSD data per 125 us microframe (8000 microframes/sec).
// DSD64 stereo: 2.8224 MHz * 2 ch / 8 / 8000 = 88.2 bytes/microframe.
inline size_t bytesPerMicroframeNative(DsdRate rate, int channels) {
  return (dsdRateHz(rate) / 8) * static_cast<size_t>(channels) / 8000;
}

// Bytes of DoP PCM data per microframe at the given PCM rate.
inline size_t bytesPerMicroframeDoP(uint32_t dopPcmRateHz, int channels,
                                    int bytesPerSample) {
  return (static_cast<size_t>(dopPcmRateHz) / 8000) *
         static_cast<size_t>(channels) * static_cast<size_t>(bytesPerSample);
}

// Splits a byte stream into isochronous microframe packets when the
// per-microframe size is fractional (e.g. DSD64 stereo = 88.2 bytes).
// The fractional remainder is accumulated so the long-term average is exact.
class MicroframeSizer {
 public:
  explicit MicroframeSizer(size_t bytesPerSecond)
      : bytesPerSecond_(bytesPerSecond) {}

  // Bytes for the next 125 us microframe.
  size_t nextPacketBytes() {
    const uint64_t total =
        static_cast<uint64_t>(bytesPerSecond_) + remainder_;
    remainder_ = total % 8000;
    return static_cast<size_t>(total / 8000);
  }

 private:
  size_t bytesPerSecond_;
  uint64_t remainder_ = 0;
};

// Mode decision, mirroring Lark's FUN_001cda0c order:
//   1. dsdDop toggle off           -> convert to PCM
//   2. Enhanced DSP active (needs PCM) -> convert to PCM
//   3. channels outside 1..2      -> convert to PCM
//   4. native alt setting present AND native rate accepted -> native
//   5. DoP possible               -> DoP
//   6. otherwise                  -> convert to PCM
DsdMode decideMode(bool dsdDopEnabled, bool enhancedDsp, int channels,
                   bool hasNativeAlt, bool nativeRateOk, bool dopOk);

// Picks the PCM target rate for DSD->PCM conversion from the DAC's
// advertised rate list, in Lark's priority order
// (176400, 88200, 192000, 96000, 44100, 48000).
// Returns 0 when none of the priority rates is advertised.
uint32_t pickPcmTargetRate(const uint32_t* dacRates, size_t count);

}  // namespace dsd
