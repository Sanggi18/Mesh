// test_dsd.cpp — Host unit tests for the DSD implementation.
// Build: g++ -std=c++17 -I.. -o test_dsd test_dsd.cpp ../dop_packer.cpp
//        ../dsd_usb.cpp ../dsd_file.cpp ../dsd_to_pcm.cpp ../dsd_jni.cpp -lm
// Or: cmake -S .. -B build && cmake --build build && ./build/test_dsd
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

#include "dop_packer.h"
#include "dsd_file.h"
#include "dsd_jni.h"
#include "dsd_to_pcm.h"
#include "dsd_usb.h"

static int failures = 0;

#define CHECK(cond)                                                     \
  do {                                                                  \
    if (!(cond)) {                                                      \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);       \
      ++failures;                                                       \
    }                                                                   \
  } while (0)

using namespace dsd;

static void testRates() {
  CHECK(dopPcmRateHz(DsdRate::kDsd64) == 176400);
  CHECK(dopPcmRateHz(DsdRate::kDsd128) == 352800);
  CHECK(dopPcmRateHz(DsdRate::kDsd256) == 705600);
  CHECK(dopPcmRateHz(DsdRate::kDsd512) == 1411200);
  CHECK(dopPcmRateHz(DsdRate::kDsd1024) == 0);
  CHECK(!dopFeasible(DsdRate::kDsd1024));
  CHECK(dopFeasible(DsdRate::kDsd64));
  CHECK(nativeUsbRateHz(DsdRate::kDsd64) == 88200);
  CHECK(nativeUsbRateHz(DsdRate::kDsd128) == 176400);
  CHECK(bytesPerSecondNative(DsdRate::kDsd64, 2) == 705600);
  CHECK(bytesPerMicroframeNative(DsdRate::kDsd64, 2) == 88);  // 88.2 trunc.
  CHECK(bytesPerMicroframeDoP(176400, 2, 3) == 132);           // 176.4k 24-bit.
}

static void testMicroframeSizer() {
  // DSD64 stereo = 705600 B/s -> 88.2 bytes/microframe; 5 frames = 441.
  MicroframeSizer sizer(705600);
  size_t total = 0;
  for (int i = 0; i < 5; ++i) total += sizer.nextPacketBytes();
  CHECK(total == 441);
}

static void testDoP() {
  DoPPacker packer;
  // 2 frames x 2 channels of 16-bit DSD words.
  const uint16_t words[4] = {0xAAAA, 0x5555, 0xAAAA, 0x5555};
  uint8_t out24[12] = {};
  CHECK(packer.pack24(words, 2, 2, out24) == 12);
  // Frame 0: marker 0x05 on both channels; frame 1: marker 0xFA.
  CHECK(out24[2] == 0x05 && out24[5] == 0x05);
  CHECK(out24[8] == 0xFA && out24[11] == 0xFA);
  // DSD bytes preserved: [lo][hi][marker].
  CHECK(out24[0] == 0xAA && out24[1] == 0xAA);
  CHECK(out24[3] == 0x55 && out24[4] == 0x55);
  // Reset restores the first marker to 0x05.
  packer.reset();
  CHECK(packer.currentMarker() == 0x05);
  uint8_t out32[16] = {};
  CHECK(packer.pack32(words, 2, 2, out32) == 16);
  CHECK(out32[0] == 0x00 && out32[3] == 0x05);  // padding + marker.
  CHECK(out32[8] == 0x00 && out32[11] == 0xFA);
  CHECK(out32[1] == 0xAA && out32[2] == 0xAA);
}

static void testNative() {
  const uint32_t dwords[2] = {0x69696969, 0x12345678};
  uint8_t out[8] = {};
  CHECK(NativePacker::pack(dwords, 1, 2, out) == 8);
  CHECK(out[0] == 0x69 && out[3] == 0x69);           // verbatim, LE.
  CHECK(out[4] == 0x78 && out[7] == 0x12);           // 0x12345678 LE.
  uint32_t silence[4] = {};
  CHECK(NativePacker::fillSilence(silence, 4) == 4);
  for (int i = 0; i < 4; ++i) CHECK(silence[i] == 0x69696969);
}

static void testModeDecision() {
  CHECK(decideMode(false, false, 2, true, true, true) ==
        DsdMode::kConvertToPcm);  // Toggle off.
  CHECK(decideMode(true, true, 2, true, true, true) ==
        DsdMode::kConvertToPcm);  // Enhanced DSP.
  CHECK(decideMode(true, false, 3, true, true, true) ==
        DsdMode::kConvertToPcm);  // >2 channels.
  CHECK(decideMode(true, false, 2, true, true, true) ==
        DsdMode::kNative);  // Native preferred.
  CHECK(decideMode(true, false, 2, false, false, true) ==
        DsdMode::kDoP);  // No native alt -> DoP.
  CHECK(decideMode(true, false, 2, false, false, false) ==
        DsdMode::kConvertToPcm);  // Nothing works -> convert.
  const uint32_t dacRates[] = {48000, 96000, 44100};
  CHECK(pickPcmTargetRate(dacRates, 3) == 96000);  // Priority order.
  const uint32_t dacRates2[] = {48000};
  CHECK(pickPcmTargetRate(dacRates2, 1) == 48000);
  const uint32_t dacRates3[] = {32000};
  CHECK(pickPcmTargetRate(dacRates3, 1) == 0);
}

static void putU32Le(uint8_t* p, uint32_t v) {
  p[0] = v & 0xFF;
  p[1] = (v >> 8) & 0xFF;
  p[2] = (v >> 16) & 0xFF;
  p[3] = (v >> 24) & 0xFF;
}
static void putU64Le(uint8_t* p, uint64_t v) {
  putU32Le(p, static_cast<uint32_t>(v & 0xFFFFFFFF));
  putU32Le(p + 4, static_cast<uint32_t>(v >> 32));
}
static void putU32Be(uint8_t* p, uint32_t v) {
  p[0] = (v >> 24) & 0xFF;
  p[1] = (v >> 16) & 0xFF;
  p[2] = (v >> 8) & 0xFF;
  p[3] = v & 0xFF;
}
static void putU64Be(uint8_t* p, uint64_t v) {
  putU32Be(p, static_cast<uint32_t>(v >> 32));
  putU32Be(p + 4, static_cast<uint32_t>(v & 0xFFFFFFFF));
}

static void testDsf() {
  uint8_t buf[92 + 16] = {};
  std::memcpy(buf, "DSD ", 4);
  putU64Le(buf + 4, 28);
  putU64Le(buf + 12, sizeof(buf));
  putU64Le(buf + 20, 0);
  std::memcpy(buf + 28, "fmt ", 4);
  putU64Le(buf + 32, 52);
  putU32Le(buf + 40, 1);        // format version
  putU32Le(buf + 44, 0);        // format id: raw DSD
  putU32Le(buf + 48, 2);        // channel type: stereo
  putU32Le(buf + 52, 2);        // channels
  putU32Le(buf + 56, 2822400);  // DSD64
  putU32Le(buf + 60, 1);        // bits per sample
  putU64Le(buf + 64, 64);       // sample count
  putU32Le(buf + 72, 4096);     // block size per channel
  std::memcpy(buf + 80, "data", 4);
  putU64Le(buf + 84, 16);
  std::memset(buf + 92, 0x69, 16);

  DsdFileInfo info;
  CHECK(parseDsdFile(buf, sizeof(buf), info));
  CHECK(info.format == DsdFileInfo::Format::kDsf);
  CHECK(info.channels == 2);
  CHECK(info.sampleRate == 2822400);
  CHECK(info.dataOffset == 92);
  CHECK(info.dataSize == 16);
  CHECK(!info.isDst);

  // DST must be rejected.
  putU32Le(buf + 44, 1);
  CHECK(!parseDsdFile(buf, sizeof(buf), info));
  CHECK(info.isDst);
  putU32Le(buf + 44, 0);

  // Bad magic rejected.
  buf[0] = 'X';
  CHECK(!parseDsdFile(buf, sizeof(buf), info));
}

static void testDsdiff() {
  // FRM8 + PROP(SND: FS/CHNL/CMPR) + DSD chunk.
  uint8_t buf[256] = {};
  size_t pos = 0;
  std::memcpy(buf + pos, "FRM8", 4);
  pos += 4;
  putU64Be(buf + pos, 0);
  pos += 8;
  std::memcpy(buf + pos, "DSD ", 4);
  pos += 4;
  // PROP chunk.
  std::memcpy(buf + pos, "PROP", 4);
  pos += 4;
  const size_t propSizePos = pos;
  pos += 8;
  std::memcpy(buf + pos, "SND ", 4);
  pos += 4;
  std::memcpy(buf + pos, "FS  ", 4);
  pos += 4;
  putU64Be(buf + pos, 4);
  pos += 8;
  putU32Be(buf + pos, 2822400);
  pos += 4;
  std::memcpy(buf + pos, "CHNL", 4);
  pos += 4;
  putU64Be(buf + pos, 2);
  pos += 8;
  buf[pos++] = 0x00;
  buf[pos++] = 0x02;
  std::memcpy(buf + pos, "CMPR", 4);
  pos += 4;
  putU64Be(buf + pos, 4);
  pos += 8;
  std::memcpy(buf + pos, "DSD ", 4);
  pos += 4;
  putU64Be(buf + propSizePos, pos - (propSizePos + 8));
  // DSD chunk.
  std::memcpy(buf + pos, "DSD ", 4);
  pos += 4;
  putU64Be(buf + pos, 16);
  pos += 8;
  std::memset(buf + pos, 0x69, 16);
  pos += 16;
  putU64Be(buf + 4, pos - 12);

  DsdFileInfo info;
  CHECK(parseDsdFile(buf, pos, info));
  CHECK(info.format == DsdFileInfo::Format::kDsdiff);
  CHECK(info.channels == 2);
  CHECK(info.sampleRate == 2822400);
  CHECK(info.dataSize == 16);
  CHECK(!info.isDst);
}

static void testAltSetting() {
  // Config desc (9 bytes) + AS interface alt 4 (9 bytes) +
  // FORMAT_TYPE descriptor (8 bytes).
  uint8_t desc[9 + 9 + 8] = {};
  desc[0] = 9;
  desc[1] = 0x02;  // CONFIGURATION.
  desc[9] = 9;
  desc[10] = 0x04;  // INTERFACE.
  desc[11] = 0;     // bInterfaceNumber.
  desc[12] = 4;     // bAlternateSetting = 4.
  desc[14] = 0x01;  // bInterfaceClass = Audio.
  desc[15] = 0x02;  // bInterfaceSubClass = AudioStreaming.
  desc[18] = 8;
  desc[19] = 0x24;  // CS_INTERFACE.
  desc[20] = 0x02;  // FORMAT_TYPE subtype.
  desc[21] = 0x04;  // bFormatType = IV.
  desc[22] = 4;     // bSubslotSize = 4.
  desc[23] = 32;    // bBitResolution = 32.
  auto found = findDsdAltSetting(desc, sizeof(desc));
  CHECK(found.has_value());
  CHECK(found->altSetting == 4);
  CHECK(found->subslotSize == 4);
  CHECK(found->bitResolution == 32);
  CHECK(found->formatType == 4);
  // No DSD alt: plain PCM alt setting.
  desc[21] = 0x01;
  desc[22] = 3;
  desc[23] = 24;
  CHECK(!findDsdAltSetting(desc, sizeof(desc)).has_value());
}

static void testDsdToPcm() {
  DsdToPcm conv;
  CHECK(conv.init(DsdRate::kDsd64, 176400, 16));
  CHECK(conv.ratio() == 16);
  CHECK(conv.numTaps() % 8 == 0);
  CHECK(!conv.init(DsdRate::kDsd64, 48000, 16));  // 2822400 % 48000 != 0.
  CHECK(!conv.init(DsdRate::kDsd64, 176400, 20));  // bad bit depth.
  CHECK(conv.init(DsdRate::kDsd64, 176400, 16));

  // All-ones DSD -> +1.0 -> near +32767; all-zeros -> near -32767.
  // Check only the middle (filter has settled there).
  std::vector<uint8_t> ones(4096, 0xFF);
  std::vector<int32_t> out(4096);
  const size_t n = conv.convertChannel(ones.data(), ones.size(), out.data(),
                                       out.size());
  CHECK(n == 4096 * 8 / 16);
  double midSum = 0;
  for (size_t i = n / 4; i < 3 * n / 4; ++i) {
    CHECK(out[i] >= -32768 && out[i] <= 32767);
    midSum += out[i];
  }
  CHECK(midSum / (n / 2) > 30000);  // Near full scale positive.

  std::vector<uint8_t> zeros(4096, 0x00);
  const size_t n2 = conv.convertChannel(zeros.data(), zeros.size(),
                                        out.data(), out.size());
  midSum = 0;
  for (size_t i = n2 / 4; i < 3 * n2 / 4; ++i) midSum += out[i];
  CHECK(midSum / (n2 / 2) < -30000);  // Near full scale negative.
}

static void testCApi() {
  CHECK(dsd_dop_rate(2822400) == 176400);
  CHECK(dsd_dop_rate(45158400) == 0);
  CHECK(dsd_native_rate(2822400) == 88200);
  DsdDopPacker* h = dsd_dop_create();
  CHECK(h != nullptr);
  const uint16_t words[2] = {0xAAAA, 0x5555};
  uint8_t out[6] = {};
  CHECK(dsd_dop_pack24(h, words, 1, 2, out) == 6);
  CHECK(out[2] == 0x05);
  dsd_dop_reset(h);
  CHECK(dsd_dop_pack24(h, words, 1, 2, out) == 6);
  CHECK(out[2] == 0x05);
  dsd_dop_destroy(h);
}

int main() {
  testRates();
  testMicroframeSizer();
  testDoP();
  testNative();
  testModeDecision();
  testDsf();
  testDsdiff();
  testAltSetting();
  testDsdToPcm();
  testCApi();
  if (failures == 0) {
    std::printf("ALL TESTS PASSED\n");
    return 0;
  }
  std::printf("%d TEST(S) FAILED\n", failures);
  return 1;
}
