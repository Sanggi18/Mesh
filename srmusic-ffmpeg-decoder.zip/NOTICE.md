# NOTICE — Licenses and attribution

## FFmpeg 7.1
- License: GNU Lesser General Public License v2.1 or later (LGPL-2.1+).
- Built with `--disable-everything` plus the audio decoders listed in
  `build_ffmpeg_music.sh` (flac, alac, mp3, aac, opus, vorbis, wavpack,
  ape, pcm_s16le, pcm_s24le, pcm_f32le). No GPL-licensed components are
  enabled. Source: https://ffmpeg.org/releases/ffmpeg-7.1.tar.xz
  (SHA-256 40973d44970dbc83ef302b0609f2e74982be2d85916dd2ee7472d30678a7abe6).

## androidx-media decoder_ffmpeg (JNI + Java)
- Files: `jni/ffmpeg_jni.cc`, `jni/CMakeLists.txt`,
  `jni/build_ffmpeg.sh`, `java/*.java`.
- License: Apache License, Version 2.0.
- Copyright (C) The Android Open Source Project.
- Source: https://github.com/androidx/media/tree/1.11.1/libraries/decoder_ffmpeg
  (files taken unmodified from the `release` branch).

## Idea / decoder list
- The music-only decoder-list approach follows jellyfin-androidx-media
  (https://github.com/jellyfin/jellyfin-androidx-media, GPL-3.0), which
  builds the same androidx-media module with 10 audio decoders enabled.
  No code was taken from that repository.

## SRMusic
- This package was prepared for the SRMusic Android app (package
  `com.srmusic`). It is not affiliated with Jellyfin, Google, or FFmpeg.
