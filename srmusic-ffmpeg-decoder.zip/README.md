# SRMusic FFmpeg Decoder — Music-Only Build

Decoder FFmpeg khusus musik buat SRMusic Android, dibangun dari logika
jellyfin-androidx-media / androidx-media `decoder_ffmpeg` — tapi dengan
daftar decoder yang dipangkas khusus buat dengerin musik doang.

## Yang di-build

FFmpeg 9.0.2, `--disable-everything`, cuma 11 decoder audio yang dinyalain:

```
flac alac mp3 aac opus vorbis wavpack ape pcm_s16le pcm_s24le pcm_f32le
```

Itu cover: FLAC, ALAC, MP3, AAC, Opus, Vorbis, WavPack, APE, WAV.
(Jellyfin cuma aktifin 10 decoder dan **nggak ada Opus/Vorbis** — di sini
ditambahin karena SRMusic butuh Opus.)

Yang dimatiin: video, encoder, muxer, filter, network, avformat, avdevice,
swscale, postproc. Demuxing diserahkan ke extractor Media3 — FFmpeg di
sini cuma decode, sesuai desain `decoder_ffmpeg` androidx-media.

## Isi paket

| Path | Isi |
|---|---|
| `build_ffmpeg_music.sh` | Script build FFmpeg statik (arm64-v8a + armeabi-v7a, API 26, NDK 28) |
| `jni/ffmpeg_jni.cc` | JNI wrapper androidx-media **1.11.1** (Apache 2.0, tidak diubah) |
| `jni/CMakeLists.txt` | Link `libffmpegJNI.so` dari `libavcodec/libavutil/libswresample.a` |
| `jni/build_ffmpeg.sh` | Script build asli androidx-media 1.11.1 (referensi) |
| `java/` | `FfmpegAudioDecoder`, `FfmpegAudioRenderer`, `FfmpegLibrary`, `FfmpegDecoderException`, `package-info` (Apache 2.0, dari tag **1.11.1**) |
| `prebuilt/<abi>/libffmpegJNI.so` | Hasil build, siap copas ke `jniLibs` |
| `ffmpeg-9.0.2.tar.xz` | Source FFmpeg 9.0.2 (SHA-256 di bawah) — build ulang kalau mau ubah decoder |
| `NOTICE.md` | Lisensi & atribusi |

FFmpeg 9.0.2 tarball SHA-256:
`8c3850283eb25fa026482078a04051e0be17347b09ef81a0849bec15a96e002e`

## Cara pakai di SRMusic Android (sudah ada `FfmpegRenderersFactory`)

`FfmpegRenderersFactory` lo udah pakai `FfmpegAudioRenderer` +
`EXTENSION_RENDERER_MODE_PREFER` — jadi integrasinya tinggal:

1. Copy `java/*.java` ke
   `app/src/main/java/androidx/media3/decoder/ffmpeg/`
   (atau jadi module `:decoder-ffmpeg` sendiri).
2. Copy `prebuilt/arm64-v8a/libffmpegJNI.so` dan
   `prebuilt/armeabi-v7a/libffmpegJNI.so` ke
   `app/src/main/jniLibs/<abi>/libffmpegJNI.so`.
3. Pastikan dependency Media3 ada: `media3-exoplayer`, `media3-decoder`.
4. Build. `FfmpegLibrary.isAvailable()` bakal true dan AAC/Opus/dll
   di-decode FFmpeg — bukan MediaCodec SoC (ini yang ngebantu masalah
   AAC kresek: decode-nya konsisten di semua HP).

## Build ulang sendiri

```sh
# 1. Extract source FFmpeg + pasang symlink yang dipakai CMakeLists
tar -xf ffmpeg-9.0.2.tar.xz
ln -sfn ../ffmpeg-9.0.2 jni/ffmpeg

# 2. Build static libs (butuh Android NDK, default ~/Android/sdk/ndk/28.2.13676358, API 26)
./build_ffmpeg_music.sh
# ganti ABI:  ABIS="arm64-v8a" ./build_ffmpeg_music.sh
# tambah x86_64 (emulator): ABIS="arm64-v8a armeabi-v7a x86_64" ./build_ffmpeg_music.sh
# ubah decoder: edit ENABLED_DECODERS di script
```

Terus link `.so`-nya (butuh NDK CMake toolchain):

```sh
for ABI in arm64-v8a armeabi-v7a; do
  cmake -S jni -B /tmp/ffmpeg-jni-$ABI \
    -DCMAKE_TOOLCHAIN_FILE=$ANDROID_NDK_PATH/build/cmake/android.toolchain.cmake \
    -DANDROID_ABI=$ABI -DANDROID_PLATFORM=android-26
  cmake --build /tmp/ffmpeg-jni-$ABI
  cp /tmp/ffmpeg-jni-$ABI/libffmpegJNI.so prebuilt/$ABI/
done
```

## Ukuran

Hasil build beneran (strip, FFmpeg 9.0.2, 11 decoder):
- `arm64-v8a/libffmpegJNI.so`: **1,44 MB** (1.441.888 byte)
- `armeabi-v7a/libffmpegJNI.so`: **1,24 MB** (1.238.948 byte)

Semua 11 decoder terverifikasi ada di dalam `.so` (`ff_flac_decoder`,
`ff_alac_decoder`, `ff_mp3_decoder`, `ff_aac_decoder`, `ff_opus_decoder`,
`ff_vorbis_decoder`, `ff_wavpack_decoder`, `ff_ape_decoder`,
`ff_pcm_s16le/s24le/f32le_decoder`) plus `JNI_OnLoad` yang ter-export.
Jauh lebih kecil dari FFmpeg full (10–20 MB+) karena cuma 11 decoder
audio, tanpa video/encoder/filter.

## Lisensi

- Kode JNI + Java: Apache 2.0 (Android Open Source Project).
- FFmpeg 9.0.2 yang di-build di sini: LGPL 2.1-or-later — configure
  default tanpa komponen GPL (`--disable-everything` + decoder di atas
  tidak menarik komponen GPL). Detail di `NOTICE.md`.
- Repo jellyfin-androidx-media sendiri berlisensi GPL-3.0, tapi paket ini
  TIDAK memakai kode dari repo itu — kodenya dari androidx-media
  (Apache 2.0) + FFmpeg (LGPL); cuma ide daftar decoder-nya yang
  mengikuti pola Jellyfin.
