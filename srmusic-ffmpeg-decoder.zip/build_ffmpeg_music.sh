#!/bin/bash
# build_ffmpeg_music.sh — Build a MUSIC-ONLY FFmpeg for SRMusic Android.
#
# Based on androidx-media's libraries/decoder_ffmpeg/src/main/jni/
# build_ffmpeg.sh (Apache 2.0), with the decoder list changed to music-only
# (same idea as jellyfin-androidx-media's build.sh, which enables 10 audio
# decoders). Only audio decoders are enabled; video, encoders, muxers,
# filters, network and avformat are all disabled. Media3's own extractors
# do the demuxing — FFmpeg only decodes.
#
# Usage:
#   ./build_ffmpeg_music.sh [abi ...]
#   ABIS="arm64-v8a armeabi-v7a" ./build_ffmpeg_music.sh
#   ANDROID_NDK_PATH=/path/to/ndk ANDROID_API=26 ./build_ffmpeg_music.sh
#
# Output: ffmpeg-7.1/android-libs/<abi>/libavcodec.a, libavutil.a,
#         libswresample.a  (static libs, stripped)
# Then link libffmpegJNI.so with the module's jni/CMakeLists.txt, or use
# the prebuilt .so files shipped in prebuilt/<abi>/.
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FFMPEG_DIR="${FFMPEG_DIR:-${SCRIPT_DIR}/ffmpeg-9.0.2}"

# --- Config (override via env) -------------------------------------------
ANDROID_NDK_PATH="${ANDROID_NDK_PATH:-$HOME/Android/sdk/ndk/28.2.13676358}"
ANDROID_API="${ANDROID_API:-26}"
ABIS="${ABIS:-arm64-v8a armeabi-v7a}"

# Music-only decoder list.
#   flac / alac / mp3 / aac : the big four
#   opus / vorbis           : open formats (Jellyfin's list lacks these)
#   wavpack / ape           : lossless extras
#   pcm_s16le / pcm_s24le / pcm_f32le : WAV
ENABLED_DECODERS=(flac alac mp3 aac opus vorbis wavpack ape pcm_s16le pcm_s24le pcm_f32le)

[[ ! -d "$ANDROID_NDK_PATH" ]] && echo "No NDK at $ANDROID_NDK_PATH" && exit 1
[[ ! -d "$FFMPEG_DIR" ]] && echo "No FFmpeg source at $FFMPEG_DIR" && exit 1

HOST_PLATFORM="linux-x86_64"
TOOLCHAIN_PREFIX="${ANDROID_NDK_PATH}/toolchains/llvm/prebuilt/${HOST_PLATFORM}/bin"
JOBS="$(nproc 2>/dev/null || echo 4)"

COMMON_OPTIONS="
    --target-os=android
    --enable-static
    --disable-shared
    --disable-doc
    --disable-programs
    --disable-everything
    --disable-avdevice
    --disable-avformat
    --disable-swscale
    --disable-avfilter
    --disable-symver
    --enable-swresample
    --extra-ldexeflags=-pie
    --disable-v4l2-m2m
    --disable-vulkan
"

for decoder in "${ENABLED_DECODERS[@]}"; do
  COMMON_OPTIONS="${COMMON_OPTIONS} --enable-decoder=${decoder}"
done

echo "Enabled decoders: ${ENABLED_DECODERS[*]}"
echo "ABIs: ${ABIS} (API ${ANDROID_API}, NDK ${ANDROID_NDK_PATH})"

cd "$FFMPEG_DIR"

for ABI in $ABIS; do
  case "$ABI" in
    arm64-v8a)
      ARCH=aarch64; CPU=armv8-a
      CROSS="${TOOLCHAIN_PREFIX}/aarch64-linux-android${ANDROID_API}-"
      LIBDIR="${FFMPEG_DIR}/android-libs/arm64-v8a"
      EXTRA_CFLAGS=""
      ;;
    armeabi-v7a)
      ARCH=arm; CPU=armv7-a
      CROSS="${TOOLCHAIN_PREFIX}/armv7a-linux-androideabi${ANDROID_API}-"
      LIBDIR="${FFMPEG_DIR}/android-libs/armeabi-v7a"
      EXTRA_CFLAGS="-march=armv7-a -mfloat-abi=softfp"
      EXTRA_LDFLAGS="-Wl,--fix-cortex-a8"
      ;;
    x86_64)
      ARCH=x86_64; CPU=x86-64
      CROSS="${TOOLCHAIN_PREFIX}/x86_64-linux-android${ANDROID_API}-"
      LIBDIR="${FFMPEG_DIR}/android-libs/x86_64"
      EXTRA_CFLAGS=""
      EXTRA_LDFLAGS=""
      ;;
    x86)
      ARCH=x86; CPU=i686
      CROSS="${TOOLCHAIN_PREFIX}/i686-linux-android${ANDROID_API}-"
      LIBDIR="${FFMPEG_DIR}/android-libs/x86"
      EXTRA_CFLAGS=""
      EXTRA_LDFLAGS=""
      ;;
    *)
      echo "Unknown ABI: $ABI"; exit 1;;
  esac

  echo "=== Building $ABI ==="
  mkdir -p "$LIBDIR"
  ./configure \
      --prefix="$LIBDIR" \
      --libdir="$LIBDIR" \
      --arch="$ARCH" \
      --cpu="$CPU" \
      --cross-prefix="$CROSS" \
      --nm="${TOOLCHAIN_PREFIX}/llvm-nm" \
      --ar="${TOOLCHAIN_PREFIX}/llvm-ar" \
      --ranlib="${TOOLCHAIN_PREFIX}/llvm-ranlib" \
      --strip="${TOOLCHAIN_PREFIX}/llvm-strip" \
      --extra-cflags="$EXTRA_CFLAGS" \
      --extra-ldflags="${EXTRA_LDFLAGS:-}" \
      ${COMMON_OPTIONS}
  make -j"$JOBS"
  make install-libs
  make clean
  echo "=== $ABI done: $(ls -la "$LIBDIR"/*.a) ==="
done

echo "ALL DONE. Static libs in $FFMPEG_DIR/android-libs/<abi>/"
