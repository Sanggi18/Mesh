// module-build.gradle.kts — contoh build.gradle.kts kalau paket ini
// dijadikan module Gradle sendiri (mis. :decoder-ffmpeg).
// Kalau .so prebuilt dipakai langsung dari app/src/main/jniLibs, file ini
// tidak diperlukan.
//
// plugins {
//     id("com.android.library")
// }
//
// android {
//     namespace = "androidx.media3.decoder.ffmpeg"
//     compileSdk = 36
//     ndkVersion = "28.2.13676358"
//     defaultConfig { minSdk = 26 }
//     externalNativeBuild {
//         cmake { path = file("jni/CMakeLists.txt"); version = "3.22.1" }
//     }
//     sourceSets { getByName("main") { java.srcDirs("java") } }
// }
//
// dependencies {
//     implementation("androidx.media3:media3-exoplayer:1.9.0")
//     implementation("androidx.media3:media3-decoder:1.9.0")
// }
