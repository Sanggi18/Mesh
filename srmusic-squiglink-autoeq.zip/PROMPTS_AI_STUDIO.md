# Prompt AI Studio — Integrasi SquigLink AutoEq ke SRMusic

**Cara pakai:** kirim **satu bagian per satu**, tunggu AI Studio selesai, baru
lanjut ke bagian berikutnya. Jangan kirim semua sekaligus. Setiap bagian
mandiri: sudah termasuk file referensi yang harus dibaca dulu.

**Referensi utama (ada di zip modul `srmusic-squiglink-autoeq.zip`):**
folder `src/main/kotlin/com/srmusic/autoeq/` berisi implementasi yang sudah
diuji (38 unit test PASS) — jadikan itu sumber kebenaran untuk logika.
Di sini tugasnya **memindahkan** kode itu ke tree SRMusic dan menyambungkannya
ke playback + UI, bukan menulis ulang logikanya dari nol.

**Pola arsitektur SRMusic yang harus diikuti:**
- `core/` tidak boleh import `ui/` (Clean Architecture).
- DI manual: singleton lazy di `SRMusicApp` (`app/src/main/java/com/srmusic/SRMusicApp.kt`),
  ViewModel di-`provideFactory()` di `AppRoot.kt`
  (`app/src/main/java/com/srmusic/AppRoot.kt`, lihat pola `EqualizerViewModel`).
- Media3 **1.11.1** (lihat `gradle/libs.versions.toml`) — jangan tambah
  Retrofit/OkHttp, network tetap pakai `java.net.HttpURLConnection`
  seperti di modul referensi.
- Jangan sentuh jalur bit-perfect (`UsbAudioSink` di
  `FfmpegRenderersFactory.kt` baris 97–114).

---

## Bagian 1 — Data layer (client + parser + cache + model)

Baca dulu file-file ini di repo SRMusic:
- `app/src/main/java/com/srmusic/SRMusicApp.kt` (pola singleton lazy + `applicationContext`)
- `gradle/libs.versions.toml` (konfirmasi tidak ada Retrofit/OkHttp — jangan tambahkan)

Lalu baca referensi di zip modul:
- `src/main/kotlin/com/srmusic/autoeq/Models.kt`
- `src/main/kotlin/com/srmusic/autoeq/Json.kt`
- `src/main/kotlin/com/srmusic/autoeq/SquigLinkClient.kt`
- `src/main/kotlin/com/srmusic/autoeq/FrParser.kt`
- `src/main/kotlin/com/srmusic/autoeq/PeqProfileStore.kt`

Tugas: buat package baru `com.srmusic.core.data.autoeq` dengan file-file
berikut, diadaptasi dari referensi (sesuaikan package, pakai
`context.filesDir` untuk cache/store, coroutine di dispatcher IO):

1. `Models.kt` — data class yang sama seperti referensi: `SquigSite`,
   `IemEntry`, `FrequencyResponse`, `ParametricFilter`, `PeqProfile`
   (field: `preampDb`, `filters`, `iemName`, `source`, `rig`,
   `targetName`), `TargetCurve`.
2. `Json.kt` — parser JSON minimal dari referensi (tanpa library baru).
   Catatan: `org.json` ada di Android, tapi parser referensi dipakai apa
   adanya supaya perilakunya sama dengan yang sudah diuji.
3. `SquigLinkClient.kt` — fetch squig.link dengan `HttpURLConnection`:
   - `GET https://squig.link/squigsites.json` → daftar 125 situs reviewer.
   - `GET https://<username>.squig.link<folder>data/phone_book.json` →
     daftar IEM per situs. Perhatian: field `file` di `phone_book.json`
     bisa string ATAU list (varian nozzle/mode) — tangani keduanya.
   - `GET https://<username>.squig.link<folder>data/<file> L.txt` dan
     `R.txt` (URL-encoded) → FR mentah format REW.
   - WAJIB header `User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64;
     rv:109.0) Gecko/20100101 Firefox/119.0`.
   - Cache 24 jam di `filesDir/autoeq-cache/` (berdasarkan umur file).
   - Kalau hanya satu channel yang ada (L atau R 404), pakai yang ada;
     kalau dua-duanya ada, rata-rata dB per frekuensi (lihat `FrParser`).
4. `FrParser.kt` — parse REW txt (lewati baris `*`, parse 3 kolom
   `freq dB phase`), gabung L+R, interpolasi log, dan fungsi normalisasi.
5. `PeqProfileStore.kt` — simpan profil hasil fit sebagai JSON di
   `filesDir/autoeq-profiles/`, kunci per perangkat output (`usb:` /
   `bt:` / `kabel` / `bawaan` / `lain:`) + nama IEM, supaya tidak hitung
   ulang setiap buka aplikasi.

Jangan buat UI atau wiring playback di bagian ini. Daftarkan client +
store sebagai singleton lazy di `SRMusicApp` (ikuti pola
`equalizerPreferences` di file yang sama).

**Tulis kode saja, jangan compile/build/emulator.**

---

## Bagian 2 — Fitter + target asset

Baca dulu file-file ini di zip modul (referensi):
- `src/main/kotlin/com/srmusic/autoeq/BiquadMath.kt`
- `src/main/kotlin/com/srmusic/autoeq/AutoEqFitter.kt`
- `src/main/kotlin/com/srmusic/autoeq/TargetCurves.kt`
- `src/main/assets/targets/harman_in-ear_2019.csv`
- `src/main/assets/targets/super_22.csv`
- `src/test/kotlin/com/srmusic/autoeq/AutoEqFitterTest.kt`
  (untuk memahami perilaku yang harus dipertahankan)

Tugas: buat package baru `com.srmusic.core.audio.autoeq` dengan:

1. `BiquadMath.kt` — port dari referensi apa adanya: koefisien biquad
   RBJ cookbook (peaking, low shelf, high shelf), `BiquadFilter` /
   `BiquadChain` stateful per channel, dan `combinedDb()` untuk
   menghitung respons gabungan (dipakai juga untuk preview kurva di UI
   nanti). Jangan ubah rumusnya — sudah diuji.
2. `AutoEqFitter.kt` — port dari referensi apa adanya, termasuk tiga hal
   yang JANGAN diubah:
   - Frekuensi band tetap 31/62/125/250/500/1000/2000/4000/8000/16000 Hz,
     Q 1,0; band 1 = low shelf, band 10 = high shelf, sisanya peaking.
   - Frekuensi evaluasi shelf: low shelf di 20 Hz, high shelf di 20 kHz
     (bukan di fc — di fc shelf hanya memberi ~setengah gain).
   - `TREBLE_HOLD_HZ = 12_000.0`: kurva error ditahan konstan di atas
     12 kHz karena pengukuran coupler 711 di ujung treble tidak bisa
     dipercaya (tanpa ini, preamp fixture 7Hz Eternal jadi −12,73 dB).
   - Preamp = minus puncak respons gabungan; clamp gain ±12 dB.
3. `TargetCurves.kt` — loader target dari asset (baca CSV dari
   `assets/targets/` via `context.assets`).
4. Salin dua file target ke `app/src/main/assets/targets/`:
   `harman_in-ear_2019.csv` (default) dan `super_22.csv`.
   Jangan ubah isi CSV-nya.

Verifikasi logika dengan contoh yang sama seperti test referensi: fit
7Hz Eternal (fixture di `src/test/resources/7hz_eternal_R.txt`) melawan
Harman IE 2019 harus menghasilkan 10 filter, gain dalam ±12 dB,
preamp −2,89 dB, dan residual ~0,00 dB di semua band.

Jangan buat UI atau wiring playback di bagian ini.

**Tulis kode saja, jangan compile/build/emulator.**

---

## Bagian 3 — Biquad AudioProcessor + wiring playback + bypass bit-perfect

Baca dulu file-file ini di repo SRMusic:
- `app/src/main/java/com/srmusic/core/playback/EqualizerAudioEngine.kt`
  (pola bypass: `active = enabled && !isBitPerfectEnabled` — tiru pola ini)
- `app/src/main/java/com/srmusic/core/playback/FfmpegRenderersFactory.kt`
  (khususnya `buildAudioSink` baris 92–130: cabang bit-perfect baris
  97–114 dan cabang non-bit-perfect baris 123 ke bawah)
- `app/src/main/java/com/srmusic/core/playback/PlaybackManager.kt`
  (cari bagaimana `isBitPerfectEnabled` dibaca dan bagaimana sink /
  renderer di-rebuild saat setting berubah)

Lalu baca referensi di zip modul:
- `src/main/kotlin/com/srmusic/autoeq/BiquadAudioProcessor.kt`
  (baca KDoc-nya sampai habis — ada dua detail penting Media3 1.11.1:
  `BaseAudioProcessor.configure()` hanya mengisi field `pending*`, jadi
  prosesor menyimpan format hasil configure di field sendiri; dan
  profil yang dipasang pertama kali baru berlaku setelah sink
  di-configure ulang, yaitu saat pindah track / seek)

Tugas:

1. Buat `com.srmusic.core.audio.autoeq.BiquadAudioProcessor` (port dari
   referensi): Media3 `AudioProcessor` (`@UnstableApi`) yang menerapkan
   `PeqProfile` dari Bagian 2. Mendukung float + 16-bit, 1–8 channel,
   recompute koefisien saat sample rate berubah, bypass total saat
   disabled (sinyal lewat tanpa proses).
2. Buat `AutoEqManager` di `com.srmusic.core.playback` (atau di
   `core/audio/autoeq`, yang penting `core/` dan tidak import `ui/`):
   memegang satu instance `BiquadAudioProcessor`, profil aktif, dan
   status enabled. Daftarkan sebagai singleton lazy di `SRMusicApp`.
   API minimal: `setProfile(profile: PeqProfile?)`,
   `setEnabled(Boolean)`, `setBitPerfect(Boolean)`,
   `processor: BiquadAudioProcessor`.
   Aturan aktif: `enabled && profile != null && !isBitPerfect`.
3. Wiring di `FfmpegRenderersFactory.buildAudioSink`: di cabang
   **non-bit-perfect saja** (baris 123 ke bawah), tambahkan
   `.setAudioProcessors(arrayOf(autoEqManager.processor))` pada
   `DefaultAudioSink.Builder`. Cabang bit-perfect (baris 97–114)
   **JANGAN disentuh** — AutoEq tidak boleh masuk jalur USB/DSD.
4. Sambungkan `setBitPerfect` ke sumber yang sama dengan
   `EqualizerAudioEngine` (saat pengguna mengaktifkan/mematikan
   bit-perfect, manager harus tahu — ikuti cara `EqualizerAudioEngine`
   menerima perubahan itu).
5. Saat profil aktif diganti (pengguna memilih IEM lain), panggil
   `setProfile` lalu rebuild sink / pindah track supaya prosesor
   di-configure ulang — jangan klaim profil langsung berlaku di tengah
   lagu yang sedang jalan kalau sink belum di-configure ulang.

Jangan buat UI di bagian ini.

**Tulis kode saja, jangan compile/build/emulator.**

---

## Bagian 4 — UI picker IEM (search + filter sumber, kartu profil, preview kurva)

Baca dulu file-file ini di repo SRMusic:
- `app/src/main/java/com/srmusic/ui/equalizer/EqualizerScreen.kt` dan
  `app/src/main/java/com/srmusic/ui/equalizer/core/EqualizerViewModel.kt`
  (pola layar + ViewModel + Action + UiState — tiru polanya)
- `app/src/main/java/com/srmusic/AppRoot.kt` (pola wiring ViewModel
  dengan `appViewModel(...)` + `provideFactory(...)`, lihat
  `EqualizerViewModel` sekitar baris 120)
- `app/src/main/java/com/srmusic/ui/navigation/AppNavigation.kt`
  (pola membuka layar lewat `NavigationAction` /
  `navigationState.isEqualizerOpen` — tambahkan state serupa untuk
  layar AutoEq, misalnya `isAutoEqOpen`)

Tugas: buat package baru `com.srmusic.ui.autoeq`:

1. `AutoEqViewModel` (+ `AutoEqAction`, `AutoEqUiState` di
   `ui/autoeq/core/`, mengikuti pola equalizer):
   - State: daftar situs reviewer (dari `SquigLinkClient`), situs
     terpilih, query pencarian, daftar IEM hasil filter, profil aktif
     (dari `PeqProfileStore` + `AutoEqManager`), status loading/error.
   - Action: pilih situs, ketik pencarian, pilih IEM → fetch FR →
     fit (pakai `AutoEqFitter` Bagian 2, target default Harman IE 2019,
     bisa diganti ke Super 22) → simpan profil → pasang ke
     `AutoEqManager` → tandai profil aktif.
   - Tampilkan error dengan jelas kalau fetch gagal (offline, IEM
     tidak punya file FR, situs berubah) — jangan diam-diam gagal.
2. `AutoEqScreen` (Compose): layar picker IEM dengan
   - TextField pencarian (filter nama IEM),
   - chip filter sumber (situs reviewer; default "Harpo" — data
     terlengkap untuk IEM),
   - daftar IEM (nama + harga kalau ada di `phone_book.json`),
   - kartu profil aktif: nama IEM, sumber, rig, target, preamp, dan
     10 gain filter dalam tabel kecil,
   - preview kurva: gambar respons gabungan biquad (pakai
     `BiquadMath.combinedDb()` dari Bagian 2) dan kurva error
     target−FR di atas grid log 20 Hz–20 kHz, digambar dengan Canvas
     Compose sederhana (tanpa library chart baru).
3. Tambahkan entri masuk ke layar ini dari layar Equalizer (tombol
   "AutoEq / IEM" di `EqualizerScreen`) dan wiring navigasi di
   `AppRoot.kt` + `AppNavigation.kt` mengikuti pola equalizer.
4. Cantumkan atribusi di bawah layar: "Data pengukuran: squig.link
   (CC BY 4.0) — sumber: <nama situs reviewer>".

Jangan ubah logika fitter/prosesor di bagian ini.

**Tulis kode saja, jangan compile/build/emulator.**
