# SRMusic — SquigLink AutoEq (PEQ dari squig.link, live)

Modul Kotlin standalone: ambil pengukuran IEM/headphone langsung dari
[squig.link](https://squig.link), hitung koreksi PEQ (AutoEq-style) **di HP**,
terapkan sebagai biquad parametrik di pipeline Media3 — otomatis ke-import
dan ke-load di perangkat, tanpa server perantara dan tanpa file `.txt` manual.

```
pilih IEM di picker
  -> SquigLinkClient GET squigsites.json + phone_book.json (cache 24 jam)
  -> GET <file> L.txt / R.txt (FR mentah format REW)
  -> FrParser (parse + gabung L/R)
  -> AutoEqFitter vs target (Harman IE 2019 / Super 22)
  -> PeqProfile (preamp + 10 filter parametrik)
  -> PeqProfileStore (JSON, per perangkat output)
  -> BiquadAudioProcessor (Media3 AudioProcessor, RBJ biquad)
  -> suara terkoreksi; mati total saat bit-perfect aktif
```

## Isi paket

| File | Isi |
|---|---|
| `src/main/kotlin/com/srmusic/autoeq/Models.kt` | Data class: site, IEM, FR, filter, profil, target |
| `src/main/kotlin/com/srmusic/autoeq/Json.kt` | Parser JSON minimal tanpa dependensi (untuk JVM + Android) |
| `src/main/kotlin/com/srmusic/autoeq/SquigLinkClient.kt` | Fetch squig.link via `HttpURLConnection`, cache 24 jam |
| `src/main/kotlin/com/srmusic/autoeq/FrParser.kt` | Parse REW/CSV, interpolasi log, gabung L/R |
| `src/main/kotlin/com/srmusic/autoeq/TargetCurves.kt` | Loader target bawaan |
| `src/main/kotlin/com/srmusic/autoeq/AutoEqFitter.kt` | Fit 10 filter parametrik (koreksi residual iteratif) |
| `src/main/kotlin/com/srmusic/autoeq/BiquadMath.kt` | Koefisien biquad RBJ + filter/chain stateful |
| `src/main/kotlin/com/srmusic/autoeq/BiquadAudioProcessor.kt` | Media3 `AudioProcessor` (float + 16-bit) |
| `src/main/kotlin/com/srmusic/autoeq/PeqProfileStore.kt` | Simpan profil hasil fit (JSON per perangkat + IEM) |
| `src/main/assets/targets/harman_in-ear_2019.csv` | Target Harman IE 2019 (AutoEq, MIT) |
| `src/main/assets/targets/super_22.csv` | Target Super 22 (squig.link, CC BY 4.0) |
| `src/test/kotlin/com/srmusic/autoeq/*Test.kt` | 38 unit test JVM (JUnit 4) |
| `src/test/resources/7hz_eternal_R.txt` | Fixture FR asli (Harpo, lihat `README_FIXTURES.md`) |
| `PROMPTS_AI_STUDIO.md` | 4 prompt AI Studio (Bahasa Indonesia) untuk integrasi |
| `build.sh` | Compile + test tanpa Gradle (kotlinc langsung) |

## Endpoint squig.link (diverifikasi live 2026-11-20)

Pola URL mengikuti crawler resmi AutoEq (`dbtools/squig_crawler.py`):

1. `GET https://squig.link/squigsites.json` — 125 situs reviewer
   (`[{name, username, dbs: [{type: "IEMs"|"Headphones", folder}]}]`).
2. `GET https://<username>.squig.link<folder>data/phone_book.json` — daftar
   IEM (`[{name, phones: [{name, file, reviewScore, reviewLink, price,
   shopLink}]}]`). Contoh: Harpo = 77 section, 195 IEM. Perhatian: field
   `file` kadang string, kadang **list** (varian nozzle/mode satu model).
3. `GET https://<username>.squig.link<folder>data/<file> L.txt` dan `R.txt`
   (URL-encoded) — FR mentah format REW: baris komentar `*`, header
   `Freq(Hz) SPL(dB) Phase(degrees)`, data `freq<TAB>dB<TAB>phase`.
   Tidak semua IEM punya dua channel (7Hz Eternal di Harpo hanya punya R —
   client memakai yang ada, rata-rata kalau dua-duanya ada).
4. WAJIB header `User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64;
   rv:109.0) Gecko/20100101 Firefox/119.0` (cara crawler AutoEq).

## Cara kerja fitter

1. Interpolasi FR + target ke grid log 20 Hz–20 kHz (240 titik).
2. Smoothing 1/6 oktaf, normalisasi di 1 kHz.
3. Kurva error = target − FR.
4. Fit 10 band (31/62/125/250/500/1k/2k/4k/8k/16k Hz, Q 1,0) dengan
   koreksi residual iteratif 64 ronde (model `convert_graphic` dac-control):
   band 1 = low shelf, band 10 = high shelf, sisanya peaking. Shelf
   dievaluasi di 20 Hz / 20 kHz (bukan di fc — di fc shelf hanya memberi
   ~setengah gain).
5. Preamp = minus puncak respons gabungan (supaya tidak clipping).
6. **Error di atas 12 kHz ditahan konstan** (lihat `TREBLE_HOLD_HZ`):
   pengukuran coupler 711 di ujung treble tidak bisa dipercaya.

### Contoh hasil nyata (fixture test)

7Hz Eternal (Harpo) vs Harman IE 2019 — residual **0,00 dB di semua band**:

| Band | Jenis | Freq | Gain |
|---|---|---|---|
| 1 | Low shelf | 31 Hz | +1,44 dB |
| 2 | Peaking | 62 Hz | +1,38 dB |
| 3 | Peaking | 125 Hz | −1,21 dB |
| 4 | Peaking | 250 Hz | −2,06 dB |
| 5 | Peaking | 500 Hz | −0,15 dB |
| 6 | Peaking | 1000 Hz | +0,76 dB |
| 7 | Peaking | 2000 Hz | −2,65 dB |
| 8 | Peaking | 4000 Hz | +4,52 dB |
| 9 | Peaking | 8000 Hz | −3,32 dB |
| 10 | High shelf | 16000 Hz | +1,73 dB |

Preamp **−2,89 dB**. Tanpa treble-hold, error mentah di 20 kHz mencapai
+20,68 dB (FR terukur jatuh ke −42 dB) dan preamp akan jadi −12,73 dB —
itu yang dihindari.

## Build & test

```bash
./build.sh          # compile + jalankan 38 unit test (JUnit 4)
./build.sh compile  # hanya compile
```

Tanpa Gradle (Gradle di VM ini tidak bisa mengunduh dependensi karena
sandbox memblokir TCP Java; curl bisa). `build.sh` mengunduh sekali ke
`tools/` bila belum ada: Kotlin compiler 2.4.21, media3-common 1.11.1,
androidx.annotation 1.9.1, Guava 32.1.2-android, JUnit 4.13.2,
hamcrest-core 1.3, android.jar stub (hanya untuk test JVM).

**Hasil verifikasi 2026-11-20: `OK (38 tests)` — semua PASS.**

Catatan test:
- `SquigLinkClientTest` memakai transport palsu (override `httpGet`),
  karena sandbox VM memblokir semua TCP dari proses Java (bahkan ke
  localhost). Transport asli (`HttpURLConnection`) adalah wrapper tipis;
  endpoint-nya sudah diverifikasi live dengan curl (lihat atas).
- Test prosesor memakai `android.jar` stub — tidak ada method Android yang
  benar-benar dipanggil oleh kode yang di-test.

## Integrasi ke SRMusic

Lihat `PROMPTS_AI_STUDIO.md` (4 bagian berurutan). Ringkasnya:

- **Bagian 1** — data layer (`core/data/autoeq/`): client + parser + store.
- **Bagian 2** — fitter + target asset (`core/audio/autoeq/`,
  `app/src/main/assets/targets/`).
- **Bagian 3** — `BiquadAudioProcessor` + wiring di
  `FfmpegRenderersFactory.buildAudioSink` (cabang non-bit-perfect saja,
  via `DefaultAudioSink.Builder.setAudioProcessors(...)`).
- **Bagian 4** — UI picker IEM + preview kurva (`ui/autoeq/`).

Aturan yang dijaga modul ini: EQ **mati total** saat bit-perfect aktif
(pola yang sama dengan `EqualizerAudioEngine`: `active = enabled &&
!isBitPerfectEnabled`), dan tidak ada file/lisensi yang dilanggar (di bawah).

## Lisensi & atribusi

- Kode modul ini: dibuat untuk SRMusic (ikuti lisensi repo SRMusic).
- Data pengukuran squig.link: **CC BY 4.0** — atribusi ke squig.link dan
  reviewer yang bersangkutan wajib dicantumkan di UI/about app bila data
  didistribusikan ulang. Modul ini hanya me-fetch data saat runtime dan
  tidak membundel pengukuran (kecuali fixture test — lihat
  `src/test/resources/README_FIXTURES.md`).
- Target Harman IE 2019: dari repo jaakkopasanen/AutoEq (**MIT**).
- Target Super 22: dari squig.link (**CC BY 4.0**).
- Media3: **Apache 2.0**.

## Keterbatasan (jujur)

- **Rig beda, hasil beda.** Pengukuran 711 vs 5128 tidak bisa dibandingkan
  langsung. Profil selalu menyimpan `source` + `rig`; jangan campur
  pengukuran dari rig berbeda untuk satu IEM.
- **Treble > 12 kHz tidak dikejar** (lihat `TREBLE_HOLD_HZ`). Artefak
  resonansi coupler di ~8 kHz juga ada di data mentah — smoothing 1/6
  oktaf hanya meredam, bukan menghilangkan.
- **Fit iteratif fixed-frequency bukan least-squares penuh** seperti AutoEq
  Python (yang ikut mengoptimasi frekuensi dan Q). Hasilnya akurat pada
  frekuensi band (residual ~0 dB pada fixture) tapi bisa menyimpang di
  antara band bila kurva error berlekuk tajam.
- **Profil pertama kali dipasang saat lagu sedang jalan** baru berlaku
  setelah sink di-configure ulang (pindah track / seek) — lihat KDoc
  `BiquadAudioProcessor`. Profil yang diganti saat prosesor sudah aktif
  berlaku untuk buffer berikutnya.
- **Tidak ada convolver/IR** — koreksi murni parametrik (biquad), bukan
  impulse response seperti Lark Audio.
- squig.link tidak punya API resmi ber-API-key; modul ini memakai pola
  fetch yang sama dengan crawler AutoEq. Bila struktur situs berubah
  (nama file, path), client perlu disesuaikan. Hormati server: cache
  24 jam sudah diterapkan; jangan fetch ulang tanpa perlu.
