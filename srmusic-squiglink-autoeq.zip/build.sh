#!/usr/bin/env bash
# Build + unit test modul srmusic-squiglink-autoeq (JVM murni, tanpa Gradle).
#
# Kenapa tanpa Gradle: di VM ini Gradle tidak bisa mengunduh dependensi
# (sandbox memblokir TCP Java), sementara curl bisa. Jadi toolchain diunduh
# sekali lewat curl ke tools/ lalu dipakai kotlinc langsung.
#
# Penggunaan:
#   ./build.sh          # compile main + test, jalankan semua test
#   ./build.sh compile  # hanya compile (tanpa test)
#
# Kebutuhan: curl, unzip, JDK 17+ (JAVA_HOME atau ~/tools/jdk-21).
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"

# ------------------------------------------------------------------ toolchain
if [[ -n "${JAVA_HOME:-}" && -x "$JAVA_HOME/bin/java" ]]; then
  JAVA="$JAVA_HOME/bin/java"
elif [[ -x "$HOME/tools/jdk-21/bin/java" ]]; then
  export JAVA_HOME="$HOME/tools/jdk-21"
  JAVA="$JAVA_HOME/bin/java"
else
  JAVA="$(command -v java)"
fi
export JAVA_HOME="$(dirname "$(dirname "$JAVA")")"
export PATH="$JAVA_HOME/bin:$PATH"

need() { [[ -f "$1" ]]; }

if ! need tools/kotlin-compiler/kotlinc/bin/kotlinc; then
  if command -v kotlinc >/dev/null 2>&1; then
    KOTLINC="$(command -v kotlinc)"
  else
    echo "== mengunduh Kotlin compiler 2.4.21 =="
    mkdir -p tools
    curl -sL --max-time 600 -o tools/kotlin-compiler-2.4.21.zip \
      "https://github.com/JetBrains/kotlin/releases/download/v2.4.21/kotlin-compiler-2.4.21.zip"
    unzip -q -o tools/kotlin-compiler-2.4.21.zip -d tools/kotlin-compiler
    rm -f tools/kotlin-compiler-2.4.21.zip
  fi
else
  KOTLINC="tools/kotlin-compiler/kotlinc/bin/kotlinc"
fi

if ! need tools/media3/classes.jar; then
  echo "== mengunduh media3-common 1.11.1 =="
  mkdir -p tools/media3
  curl -sL --max-time 120 -o tools/media3-common-1.11.1.aar \
    "https://dl.google.com/dl/android/maven2/androidx/media3/media3-common/1.11.1/media3-common-1.11.1.aar"
  (cd tools/media3 && unzip -q -o ../media3-common-1.11.1.aar classes.jar)
fi

if ! need tools/annotation-1.9.1.jar; then
  echo "== mengunduh androidx.annotation 1.9.1 =="
  curl -sL --max-time 60 -o tools/annotation-1.9.1.jar \
    "https://dl.google.com/dl/android/maven2/androidx/annotation/annotation/1.9.1/annotation-1.9.1.jar"
fi

if ! need tools/junit-4.13.2.jar; then
  echo "== mengunduh JUnit 4.13.2 =="
  curl -sL --max-time 60 -o tools/junit-4.13.2.jar \
    "https://repo1.maven.org/maven2/junit/junit/4.13.2/junit-4.13.2.jar"
  curl -sL --max-time 60 -o tools/hamcrest-core-1.3.jar \
    "https://repo1.maven.org/maven2/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar"
fi

if ! need tools/guava-32.1.2-android.jar; then
  echo "== mengunduh Guava 32.1.2-android (dependensi media3-common) =="
  curl -sL --max-time 120 -o tools/guava-32.1.2-android.jar \
    "https://repo1.maven.org/maven2/com/google/guava/guava/32.1.2-android/guava-32.1.2-android.jar"
fi

if ! need tools/android-4.1.1.4.jar; then
  echo "== mengunduh android.jar stub (hanya untuk test JVM) =="
  curl -sL --max-time 120 -o tools/android-4.1.1.4.jar \
    "https://repo1.maven.org/maven2/com/google/android/android/4.1.1.4/android-4.1.1.4.jar"
fi

MEDIA3_CP="tools/media3/classes.jar:tools/annotation-1.9.1.jar:tools/guava-32.1.2-android.jar"
# Stub android.jar HANYA untuk menjalankan test di JVM: class AudioFormat
# media3 menyentuh class framework Android saat static init. Di HP asli
# class itu disediakan sistem; di JVM test, stub ini cukup karena tidak ada
# method Android yang benar-benar dipanggil oleh kode yang di-test.
ANDROID_STUB_CP="tools/android-4.1.1.4.jar"
TEST_CP="$MEDIA3_CP:tools/junit-4.13.2.jar:tools/hamcrest-core-1.3.jar"

# kotlin-stdlib dari distribusi kotlinc (dibutuhkan saat menjalankan test).
KOTLIN_HOME="$(dirname "$(dirname "$KOTLINC")")"
STDLIB="$KOTLIN_HOME/lib/kotlin-stdlib.jar"
if [[ ! -f "$STDLIB" ]]; then
  echo "PERINGATAN: kotlin-stdlib.jar tidak ditemukan di $STDLIB" >&2
fi

# ------------------------------------------------------------------ compile
mkdir -p build/classes/main build/classes/test
echo "== kotlinc main =="
"$KOTLINC" src/main/kotlin -cp "$MEDIA3_CP" -d build/classes/main 2>&1 | grep -v "^warning" || true
echo "== kotlinc test =="
"$KOTLINC" src/test/kotlin -cp "build/classes/main:$TEST_CP" -d build/classes/test 2>&1 | grep -v "^warning" || true

if [[ "${1:-}" == "compile" ]]; then
  echo "OK: compile selesai."
  exit 0
fi

# ------------------------------------------------------------------ test
echo "== JUnit =="
"$JAVA" \
  -cp "build/classes/main:build/classes/test:src/test/resources:$STDLIB:$ANDROID_STUB_CP:$TEST_CP" \
  org.junit.runner.JUnitCore \
  com.srmusic.autoeq.FrParserTest \
  com.srmusic.autoeq.TargetCurvesTest \
  com.srmusic.autoeq.AutoEqFitterTest \
  com.srmusic.autoeq.BiquadMathTest \
  com.srmusic.autoeq.BiquadAudioProcessorTest \
  com.srmusic.autoeq.SquigLinkClientTest \
  com.srmusic.autoeq.PeqProfileStoreTest
echo "OK: semua test PASS."
