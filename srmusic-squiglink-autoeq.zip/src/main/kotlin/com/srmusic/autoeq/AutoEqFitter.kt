package com.srmusic.autoeq

import kotlin.math.ln
import kotlin.math.pow

/**
 * Fitter AutoEq on-device: dari kurva FR (squig.link) + kurva target,
 * menghasilkan profil 10 filter parametrik.
 *
 * Algoritma — adaptasi dari `convert_graphic` di dac-control
 * (`dac/crates/features/src/peq/autoeq.rs`):
 * 1. Interpolasi FR dan target ke grid log 20 Hz–20 kHz (240 titik).
 * 2. Smoothing 1/6 oktaf (rata-rata pada jendela ±1/12 oktaf).
 * 3. Normalisasi keduanya di 1 kHz, lalu kurva error = target − FR.
 * 4. Fit 10 band pada frekuensi tetap dengan koreksi residual iteratif:
 *    tiap ronde, gain tiap band dikoreksi selisih antara respons biquad
 *    gabungan dan error pada frekuensi evaluasi band itu, sampai 64 ronde.
 *    Band 1 = low shelf, band 10 = high shelf, band 2–9 = peaking
 *    (pola yang sama dengan jalur FFMPEG Oto Music).
 * 5. Preamp = minus puncak respons gabungan (supaya tidak clipping).
 *
 * Dua hal yang perlu dipahami (bukan optimizer least-squares penuh seperti
 * AutoEq Python):
 * - Frekuensi band dan Q (1,0) tetap; hanya gain yang di-fit. Ini membuat
 *   fit ringan di HP (tanpa library optimasi) tapi tidak sepresisi AutoEq
 *   yang ikut mengoptimasi frekuensi dan Q tiap filter.
 * - Frekuensi evaluasi shelf bukan di fc-nya: shelf mencapai gain penuh
 *   jauh di bawah (low shelf) / di atas (high shelf) fc-nya, jadi low
 *   shelf dievaluasi di 20 Hz dan high shelf di 20 kHz. Kalau dievaluasi
 *   di fc, gain shelf akan membengkak ~2x dan bass/treble jadi overshoot.
 * - Kurva error ditahan konstan di atas [TREBLE_HOLD_HZ] (12 kHz):
 *   pengukuran 711 di ujung treble tidak bisa dipercaya (lihat konstanta).
 */
object AutoEqFitter {

    /** Frekuensi band hasil fit (Hz). */
    val BAND_FREQS: DoubleArray =
        doubleArrayOf(31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)

    /**
     * Frekuensi tempat tiap band dievaluasi saat fitting. Sama dengan
     * [BAND_FREQS], kecuali shelf: low shelf di 20 Hz, high shelf di 20 kHz.
     */
    val EVAL_FREQS: DoubleArray =
        doubleArrayOf(20.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 20000.0)

    /** Q semua band saat fitting (sama seperti `GRAPHIC_FIT_Q` dac-control). */
    const val FIT_Q: Double = 1.0

    /** Ronde koreksi gain (sama seperti `GRAPHIC_FIT_ROUNDS` dac-control). */
    const val FIT_ROUNDS: Int = 64

    /** Batas gain tiap filter (dB). */
    const val MAX_GAIN_DB: Double = 12.0

    /** Sample rate referensi untuk evaluasi respons biquad (Hz). */
    const val FIT_FS: Double = 48_000.0

    /**
     * Di atas frekuensi ini, kurva error ditahan konstan pada nilai di
     * frekuensi ini (tidak lagi mengikuti error mentah).
     *
     * Alasan: pengukuran coupler 711 di atas ~12 kHz didominasi artefak
     * resonansi dan rolloff pengukuran, bukan suara IEM. Pada fixture
     * 7Hz Eternal, error mentah di 20 kHz mencapai +20,68 dB (FR terukur
     * jatuh ke −42 dB) — kalau dikejar, high shelf mentok di clamp +12 dB
     * dan preamp terpaksa −12,7 dB, membuang headroom untuk seluruh lagu.
     * Menahan error di 12 kHz membuat shelf atas melanjutkan koreksi
     * dengan wajar tanpa mengejar ujung pengukuran yang tidak bisa dipercaya.
     */
    const val TREBLE_HOLD_HZ: Double = 12_000.0

    private const val GRID_MIN_HZ: Double = 20.0
    private const val GRID_MAX_HZ: Double = 20_000.0
    private const val GRID_POINTS: Int = 240
    private const val NORMALIZE_HZ: Double = 1000.0

    fun buildFilters(gains: DoubleArray): List<ParametricFilter> {
        require(gains.size == BAND_FREQS.size) { "gains harus ${BAND_FREQS.size} elemen" }
        return gains.mapIndexed { i, g ->
            val kind = when (i) {
                0 -> FilterKind.LOW_SHELF
                BAND_FREQS.lastIndex -> FilterKind.HIGH_SHELF
                else -> FilterKind.PEAKING
            }
            ParametricFilter(kind, BAND_FREQS[i], g, FIT_Q)
        }
    }

    /** Grid frekuensi log-spaced untuk interpolasi dan evaluasi. */
    fun logGrid(): DoubleArray {
        val min = ln(GRID_MIN_HZ)
        val max = ln(GRID_MAX_HZ)
        return DoubleArray(GRID_POINTS) { i ->
            Math.exp(min + (max - min) * i / (GRID_POINTS - 1))
        }
    }

    /** Smoothing 1/6 oktaf: rata-rata nilai interpolasi pada jendela ±1/12 oktaf. */
    fun smooth(points: List<FrequencyPoint>, grid: DoubleArray): DoubleArray {
        val halfWindow = 2.0.pow(1.0 / 12.0)
        return DoubleArray(grid.size) { i ->
            val f = grid[i]
            val lo = f / halfWindow
            val hi = f * halfWindow
            var sum = 0.0
            for (k in 0 until 9) {
                val t = k / 8.0
                val ff = lo * (hi / lo).pow(t)
                sum += FrParser.interpolateDb(points, ff)
            }
            sum / 9.0
        }
    }

    /** Interpolasi linear (terhadap log frekuensi) dari nilai-nilai pada grid. */
    fun valueOnGrid(grid: DoubleArray, values: DoubleArray, freqHz: Double): Double {
        require(grid.size == values.size && grid.isNotEmpty()) { "grid/values tidak cocok" }
        if (freqHz <= grid.first()) return values.first()
        if (freqHz >= grid.last()) return values.last()
        var lo = 0
        var hi = grid.size - 1
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (grid[mid] <= freqHz) lo = mid else hi = mid
        }
        val t = (ln(freqHz) - ln(grid[lo])) / (ln(grid[hi]) - ln(grid[lo]))
        return values[lo] + t * (values[hi] - values[lo])
    }

    /** Kurva error (target − FR) setelah smoothing + normalisasi, pada grid. */
    fun errorCurve(fr: FrequencyResponse, target: TargetCurve): Pair<DoubleArray, DoubleArray> {
        require(fr.points.size >= 2) { "FR butuh minimal 2 titik" }
        require(target.points.size >= 2) { "target butuh minimal 2 titik" }
        val grid = logGrid()
        val frS = smooth(fr.points, grid)
        val tgS = smooth(target.points, grid)
        val frRef = valueOnGrid(grid, frS, NORMALIZE_HZ)
        val tgRef = valueOnGrid(grid, tgS, NORMALIZE_HZ)
        val error = DoubleArray(grid.size) { i -> (tgS[i] - tgRef) - (frS[i] - frRef) }
        // Tahan error di atas TREBLE_HOLD_HZ (lihat konstanta di atas).
        val hold = valueOnGrid(grid, error, TREBLE_HOLD_HZ)
        for (i in grid.indices) {
            if (grid[i] > TREBLE_HOLD_HZ) error[i] = hold
        }
        return grid to error
    }

    /**
     * Fit profil PEQ dari FR + target.
     *
     * @param iemName nama tampil IEM (dari phone_book.json).
     * @param source nama sumber pengukuran (dari squigsites.json).
     * @param rig rig pengukuran, mis. "711".
     */
    fun fit(
        fr: FrequencyResponse,
        target: TargetCurve,
        iemName: String,
        source: String,
        rig: String,
    ): PeqProfile {
        val (grid, error) = errorCurve(fr, target)
        val bandTargets = DoubleArray(BAND_FREQS.size) { i ->
            valueOnGrid(grid, error, EVAL_FREQS[i])
        }
        val gains = bandTargets.copyOf()
        repeat(FIT_ROUNDS) {
            for (i in gains.indices) {
                val filters = buildFilters(gains)
                val response = BiquadMath.combinedDb(filters, EVAL_FREQS[i], FIT_FS)
                gains[i] = (gains[i] + (bandTargets[i] - response))
                    .coerceIn(-MAX_GAIN_DB, MAX_GAIN_DB)
            }
        }
        val filters = buildFilters(gains)
        // Preamp dari puncak respons gabungan di seluruh grid.
        var maxResponse = 0.0
        for (f in grid) {
            maxResponse = maxOf(maxResponse, BiquadMath.combinedDb(filters, f, FIT_FS))
        }
        val preampDb = -maxOf(0.0, maxResponse)
        return PeqProfile(
            iemName = iemName,
            source = source,
            rig = rig,
            targetName = target.name,
            preampDb = preampDb,
            filters = filters,
        )
    }

    /**
     * Residual fit (dB) pada tiap frekuensi evaluasi: error target dikurangi
     * respons biquad gabungan. Nol = fit sempurna pada frekuensi itu.
     * Dipakai test dan untuk menampilkan kualitas fit di UI.
     */
    fun residuals(profile: PeqProfile, fr: FrequencyResponse, target: TargetCurve): DoubleArray {
        val (grid, error) = errorCurve(fr, target)
        return DoubleArray(BAND_FREQS.size) { i ->
            val want = valueOnGrid(grid, error, EVAL_FREQS[i])
            val got = BiquadMath.combinedDb(profile.filters, EVAL_FREQS[i], FIT_FS)
            want - got
        }
    }
}
