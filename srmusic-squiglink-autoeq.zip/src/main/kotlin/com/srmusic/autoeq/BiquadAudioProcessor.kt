package com.srmusic.autoeq

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.pow

/**
 * Media3 [AudioProcessor] yang menerapkan [PeqProfile] sebagai cascade
 * biquad (RBJ cookbook) di atas PCM float/16-bit, sebelum output.
 *
 * Cara pakai (lihat juga PROMPTS_AI_STUDIO.md Bagian 3):
 * ```kotlin
 * val peq = BiquadAudioProcessor()
 * val sink = DefaultAudioSink.Builder(context)
 *     .setEnableFloatOutput(true)
 *     .setAudioProcessors(arrayOf(peq))
 *     .build()
 * peq.setProfile(profile)          // null = tidak ada koreksi
 * peq.setBitPerfect(false)         // true = prosesor nonaktif total
 * ```
 *
 * Aturan penting:
 * - Prosesor HANYA dipasang di jalur non-bit-perfect (lihat
 *   `FfmpegRenderersFactory.buildAudioSink`: jalur bit-perfect mengembalikan
 *   `UsbAudioSink` lebih dulu — prosesor ini tidak boleh ditambahkan di sana).
 *   Sebagai pengaman ganda, [setBitPerfect] membuat [isActive] false.
 * - [isActive] false saat belum ada profil / EQ dimatikan / bit-perfect:
 *   DefaultAudioSink melewati prosesor begitu saja (tanpa copy).
 * - Format yang didukung: PCM float dan PCM 16-bit, 1–8 channel.
 *   Encoding lain -> [AudioProcessor.UnhandledAudioFormatException].
 * - Profil baru yang dipasang saat prosesor sudah aktif berlaku untuk
 *   buffer berikutnya (rantai dibangun ulang langsung). Tapi transisi
 *   nonaktif -> aktif (mis. profil pertama kali dipasang saat lagu sedang
 *   jalan) baru berlaku setelah sink di-configure ulang (pindah track /
 *   seek), karena DefaultAudioSink mengecek [isActive] saat configure.
 * - Koefisien dihitung ulang tiap kali sample rate berubah (lewat
 *   [onConfigure]) dan tiap kali profil diganti.
 */
@UnstableApi
class BiquadAudioProcessor : BaseAudioProcessor() {

    @Volatile
    var profile: PeqProfile? = null
        private set

    @Volatile
    var enabled: Boolean = true
        private set

    @Volatile
    var bitPerfect: Boolean = false
        private set

    private var chain: BiquadChain? = null
    private var preampLinear: Float = 1.0f
    private var pending: ByteArray = ByteArray(0)

    /**
     * Format hasil [onConfigure] terakhir. Disimpan sendiri karena
     * BaseAudioProcessor 1.11.1 hanya mengisi field `inputAudioFormat` /
     * `outputAudioFormat` saat [flush] (saat [configure] hanya field
     * `pending*` yang diisi) — membaca `inputAudioFormat` langsung di
     * [isActive] akan selalu NOT_SET.
     */
    private var configuredFormat: AudioProcessor.AudioFormat? = null

    /** Pasang profil baru (null = lepas koreksi). Berlaku untuk buffer berikutnya. */
    @Synchronized
    fun setProfile(profile: PeqProfile?) {
        this.profile = profile
        rebuildChainIfConfigured()
    }

    @Synchronized
    fun setEnabled(enabled: Boolean) {
        this.enabled = enabled
    }

    /** true = sinyal harus bit-perfect -> prosesor nonaktif total. */
    @Synchronized
    fun setBitPerfect(bitPerfect: Boolean) {
        this.bitPerfect = bitPerfect
    }

    override fun isActive(): Boolean {
        val format = configuredFormat ?: return false
        if (!enabled || bitPerfect) return false
        if (profile == null) return false
        return format.encoding == C.ENCODING_PCM_FLOAT ||
            format.encoding == C.ENCODING_PCM_16BIT
    }

    override fun onConfigure(
        inputAudioFormat: AudioProcessor.AudioFormat,
    ): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT &&
            inputAudioFormat.encoding != C.ENCODING_PCM_16BIT
        ) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        if (inputAudioFormat.channelCount !in 1..8) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        configuredFormat = inputAudioFormat
        rebuildChain(
            sampleRate = inputAudioFormat.sampleRate,
            channelCount = inputAudioFormat.channelCount,
        )
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!isActive) return
        val format = configuredFormat ?: return
        val bytesPerFrame = format.bytesPerFrame
        if (bytesPerFrame <= 0) return
        if (!inputBuffer.hasRemaining() && pending.isEmpty()) return

        // Gabung sisa frame sebelumnya (kalau ada) dengan input baru.
        val totalBytes = pending.size + inputBuffer.remaining()
        val combined = ByteArray(totalBytes)
        var pos = 0
        if (pending.isNotEmpty()) {
            pending.copyInto(combined, 0)
            pos = pending.size
        }
        inputBuffer.get(combined, pos, inputBuffer.remaining())

        val wholeFrames = totalBytes / bytesPerFrame
        val processBytes = wholeFrames * bytesPerFrame
        // Sisa byte yang belum membentuk satu frame penuh -> tunggu buffer berikut.
        pending = if (totalBytes > processBytes) {
            combined.copyOfRange(processBytes, totalBytes)
        } else {
            ByteArray(0)
        }
        if (wholeFrames == 0) return

        val output = replaceOutputBuffer(processBytes).order(ByteOrder.nativeOrder())
        val chain = this.chain ?: return
        val channels = format.channelCount
        val frame = FloatArray(channels)
        val inBuf = ByteBuffer.wrap(combined, 0, processBytes).order(ByteOrder.nativeOrder())
        when (format.encoding) {
            C.ENCODING_PCM_FLOAT -> {
                for (i in 0 until wholeFrames) {
                    for (ch in 0 until channels) frame[ch] = inBuf.getFloat()
                    chain.processFrame(frame)
                    for (ch in 0 until channels) output.putFloat(frame[ch] * preampLinear)
                }
            }
            C.ENCODING_PCM_16BIT -> {
                for (i in 0 until wholeFrames) {
                    for (ch in 0 until channels) {
                        frame[ch] = inBuf.getShort().toFloat() / 32768.0f
                    }
                    chain.processFrame(frame)
                    for (ch in 0 until channels) {
                        val v = (frame[ch] * preampLinear).coerceIn(-1.0f, 1.0f)
                        output.putShort((v * 32767.0f).toInt().toShort())
                    }
                }
            }
        }
        output.flip()
    }

    override fun onFlush() {
        chain?.reset()
        pending = ByteArray(0)
    }

    override fun onReset() {
        chain?.reset()
        pending = ByteArray(0)
        configuredFormat = null
    }

    @Synchronized
    private fun rebuildChainIfConfigured() {
        val format = configuredFormat ?: return
        rebuildChain(format.sampleRate, format.channelCount)
    }

    private fun rebuildChain(sampleRate: Int, channelCount: Int) {
        val profile = this.profile
        if (profile == null) {
            chain = null
            preampLinear = 1.0f
            return
        }
        val sampleRateD = sampleRate.toDouble()
        val newChain = BiquadChain(channelCount)
        newChain.setFilters(profile.filters, sampleRateD)
        chain = newChain
        preampLinear = 10.0.pow(profile.preampDb / 20.0).toFloat()
    }
}
