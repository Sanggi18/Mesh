package com.srmusic.autoeq

import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Matematika biquad (Audio EQ Cookbook / RBJ), port dari PeqMath.kt
 * dac-control (yang mengikuti backend Rust `features/peq/math.rs`).
 *
 * Dipakai di dua tempat:
 * - [AutoEqFitter]: menghitung respons gabungan saat fitting (double).
 * - [BiquadAudioProcessor]: memproses audio realtime (state per channel).
 *
 * Semua koefisien dinormalisasi: [b0, b1, b2, a1, a2] (a0 = 1).
 */
object BiquadMath {

    /** Koefisien [b0, b1, b2, a1, a2] untuk satu filter pada sample rate tertentu. */
    fun coefficients(
        kind: FilterKind,
        freqHz: Double,
        q: Double,
        gainDb: Double,
        sampleRate: Double,
    ): DoubleArray = when (kind) {
        FilterKind.PEAKING -> peaking(freqHz, q, gainDb, sampleRate)
        FilterKind.LOW_SHELF -> lowShelf(freqHz, q, gainDb, sampleRate)
        FilterKind.HIGH_SHELF -> highShelf(freqHz, q, gainDb, sampleRate)
    }

    /** Koefisien dari [ParametricFilter] pada sample rate tertentu. */
    fun coefficients(filter: ParametricFilter, sampleRate: Double): DoubleArray =
        coefficients(filter.kind, filter.freqHz, filter.q, filter.gainDb, sampleRate)

    /** Magnitudo respons (dB) satu biquad pada suatu frekuensi. */
    fun responseDb(coeffs: DoubleArray, freqHz: Double, sampleRate: Double): Double {
        val w = 2.0 * Math.PI * freqHz / sampleRate
        val c1 = cos(w)
        val s1 = -sin(w)
        val c2 = cos(2.0 * w)
        val s2 = -sin(2.0 * w)
        val (b0, b1, b2, a1, a2) = coeffs
        val numRe = b0 + b1 * c1 + b2 * c2
        val numIm = b1 * s1 + b2 * s2
        val denRe = 1.0 + a1 * c1 + a2 * c2
        val denIm = a1 * s1 + a2 * s2
        val mag = sqrt(numRe * numRe + numIm * numIm) /
            sqrt(denRe * denRe + denIm * denIm)
        return 20.0 * log10(maxOf(mag, 1e-12))
    }

    /** Respons gabungan (dB) semua filter pada suatu frekuensi. */
    fun combinedDb(
        filters: List<ParametricFilter>,
        freqHz: Double,
        sampleRate: Double,
    ): Double {
        var sum = 0.0
        for (f in filters) sum += responseDb(coefficients(f, sampleRate), freqHz, sampleRate)
        return sum
    }

    private fun base(freqHz: Double, q: Double, sampleRate: Double): Pair<Double, Double> {
        val w0 = 2.0 * Math.PI * freqHz / sampleRate
        return Pair(sin(w0) / (2.0 * q), cos(w0))
    }

    private fun peaking(freqHz: Double, q: Double, gainDb: Double, sampleRate: Double): DoubleArray {
        val a = 10.0.pow(gainDb / 40.0)
        val (alpha, cos) = base(freqHz, q, sampleRate)
        val b0 = 1.0 + alpha * a
        val b1 = -2.0 * cos
        val b2 = 1.0 - alpha * a
        // Denominator memakai alpha/A supaya magnitudo tepat di f0 sama dengan gain.
        val a0 = 1.0 + alpha / a
        val a1 = -2.0 * cos
        val a2 = 1.0 - alpha / a
        return doubleArrayOf(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
    }

    private fun lowShelf(freqHz: Double, q: Double, gainDb: Double, sampleRate: Double): DoubleArray {
        val a = 10.0.pow(gainDb / 40.0)
        val (alpha, cos) = base(freqHz, q, sampleRate)
        val s = 2.0 * sqrt(a) * alpha
        val b0 = a * ((a + 1.0) - (a - 1.0) * cos + s)
        val b1 = 2.0 * a * ((a - 1.0) - (a + 1.0) * cos)
        val b2 = a * ((a + 1.0) - (a - 1.0) * cos - s)
        val a0 = (a + 1.0) + (a - 1.0) * cos + s
        val a1 = -2.0 * ((a - 1.0) + (a + 1.0) * cos)
        val a2 = (a + 1.0) + (a - 1.0) * cos - s
        return doubleArrayOf(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
    }

    private fun highShelf(freqHz: Double, q: Double, gainDb: Double, sampleRate: Double): DoubleArray {
        val a = 10.0.pow(gainDb / 40.0)
        val (alpha, cos) = base(freqHz, q, sampleRate)
        val s = 2.0 * sqrt(a) * alpha
        val b0 = a * ((a + 1.0) + (a - 1.0) * cos + s)
        val b1 = -2.0 * a * ((a - 1.0) + (a + 1.0) * cos)
        val b2 = a * ((a + 1.0) + (a - 1.0) * cos - s)
        val a0 = (a + 1.0) - (a - 1.0) * cos + s
        val a1 = 2.0 * ((a - 1.0) - (a + 1.0) * cos)
        val a2 = (a + 1.0) - (a - 1.0) * cos - s
        return doubleArrayOf(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
    }
}

/**
 * Satu biquad Direct Form I dengan state (z1, z2). State disimpan Double
 * supaya error pembulatan tidak menumpuk pada sinyal panjang; I/O Float.
 *
 * Filter dengan semua gain 0 menghasilkan koefisien identitas
 * (b0=1, sisanya 0) sehingga prosesnya bit-identical dengan input.
 */
class BiquadFilter {
    private var b0 = 1.0
    private var b1 = 0.0
    private var b2 = 0.0
    private var a1 = 0.0
    private var a2 = 0.0
    private var z1 = 0.0
    private var z2 = 0.0

    fun setCoefficients(coeffs: DoubleArray) {
        require(coeffs.size == 5) { "koefisien biquad harus 5 elemen" }
        b0 = coeffs[0]
        b1 = coeffs[1]
        b2 = coeffs[2]
        a1 = coeffs[3]
        a2 = coeffs[4]
    }

    fun setFilter(filter: ParametricFilter, sampleRate: Double) {
        setCoefficients(BiquadMath.coefficients(filter, sampleRate))
    }

    fun reset() {
        z1 = 0.0
        z2 = 0.0
    }

    fun process(x: Float): Float {
        val xd = x.toDouble()
        val y = b0 * xd + z1
        z1 = b1 * xd - a1 * y + z2
        z2 = b2 * xd - a2 * y
        return y.toFloat()
    }
}

/**
 * Rantai biquad untuk semua channel: tiap channel punya cascade sendiri
 * (state tidak boleh dibagi antar channel).
 */
class BiquadChain(channelCount: Int) {
    private val chains: List<MutableList<BiquadFilter>> =
        List(channelCount) { mutableListOf() }

    val channelCount: Int get() = chains.size

    /** Pasang ulang filter untuk sample rate tertentu (state ikut direset). */
    fun setFilters(filters: List<ParametricFilter>, sampleRate: Double) {
        for (chain in chains) {
            chain.clear()
            for (f in filters) {
                chain += BiquadFilter().also { it.setFilter(f, sampleRate) }
            }
        }
    }

    fun reset() {
        for (chain in chains) for (f in chain) f.reset()
    }

    /** Proses satu frame interleaved in-place. `frame.size` harus == channelCount. */
    fun processFrame(frame: FloatArray) {
        require(frame.size == chains.size) { "frame harus berisi ${chains.size} channel" }
        for (ch in chains.indices) {
            var sample = frame[ch]
            for (f in chains[ch]) sample = f.process(sample)
            frame[ch] = sample
        }
    }
}
