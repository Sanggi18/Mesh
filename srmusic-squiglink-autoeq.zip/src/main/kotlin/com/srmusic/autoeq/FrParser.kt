package com.srmusic.autoeq

import kotlin.math.ln

/**
 * Parser kurva respons frekuensi dari file teks squig.link / REW / AutoEq.
 *
 * Format yang diterima:
 * - REW export (file `.txt` dari squig.link): baris komentar diawali `*`,
 *   satu baris header `Freq(Hz)  SPL(dB)  Phase(degrees)`, lalu baris data
 *   `freq<TAB>dB<TAB>phase`. Line ending bisa CRLF.
 * - CSV dua kolom ala AutoEq (`frequency,raw`): `freq,dB` per baris,
 *   baris pertama boleh header.
 * - Desimal koma (locale Eropa, mis. `-2,3`) diterima seperti parser
 *   dac-control: koma dianggap pemisah desimal bila token tidak mengandung
 *   titik.
 *
 * Semua fungsi murni (tanpa I/O) supaya gampang di-test.
 */
object FrParser {

    /** Parse angka, terima koma sebagai pemisah desimal. Null bila bukan angka. */
    fun parseNumber(token: String): Double? {
        val normalized = if (token.contains(',') && !token.contains('.')) {
            token.replace(',', '.')
        } else {
            token
        }
        return normalized.toDoubleOrNull()?.takeIf { it.isFinite() }
    }

    /**
     * Parse teks REW/CSV menjadi titik-titik terurut naik (duplikat frekuensi
     * dibuang, nilai terakhir yang dipakai). Baris yang tidak bisa diparse
     * dilewati diam-diam.
     */
    fun parse(text: String): List<FrequencyPoint> {
        val raw = ArrayList<FrequencyPoint>(512)
        for (line in text.lines()) {
            val t = line.trim()
            if (t.isEmpty() || t.startsWith("*")) continue
            // Header "Freq(Hz) ..." atau "frequency,raw" — lewati.
            if (t.startsWith("Freq", ignoreCase = true) ||
                t.startsWith("frequency", ignoreCase = true)
            ) continue
            // Data dipisah tab/spasi; kalau hanya ada 1 token, coba pisah koma.
            var tokens = t.split(Regex("[\\t ]+")).filter { it.isNotEmpty() }
            if (tokens.size < 2) tokens = t.split(',').map { it.trim() }.filter { it.isNotEmpty() }
            if (tokens.size < 2) continue
            val freq = parseNumber(tokens[0]) ?: continue
            val db = parseNumber(tokens[1]) ?: continue
            if (freq > 0.0) raw += FrequencyPoint(freq, db)
        }
        raw.sortBy { it.freqHz }
        // Deduplikasi: frekuensi sama persis -> nilai terakhir menang.
        val out = ArrayList<FrequencyPoint>(raw.size)
        for (p in raw) {
            val last = out.lastOrNull()
            if (last != null && last.freqHz == p.freqHz) out[out.lastIndex] = p else out += p
        }
        return out
    }

    /**
     * Interpolasi dB pada suatu frekuensi (linear terhadap log frekuensi,
     * seperti `curve_gain_db` di dac-control). Di luar rentang, nilai tepi
     * yang dipakai (clamp).
     */
    fun interpolateDb(points: List<FrequencyPoint>, freqHz: Double): Double {
        require(points.isNotEmpty()) { "tidak ada titik untuk interpolasi" }
        if (freqHz <= points.first().freqHz) return points.first().db
        if (freqHz >= points.last().freqHz) return points.last().db
        var lo = 0
        var hi = points.size - 1
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (points[mid].freqHz <= freqHz) lo = mid else hi = mid
        }
        val (f1, g1) = points[lo]
        val (f2, g2) = points[hi]
        val t = (ln(freqHz) - ln(f1)) / (ln(f2) - ln(f1))
        return g1 + t * (g2 - g1)
    }

    /**
     * Gabung channel kiri dan kanan menjadi satu kurva: rata-rata dB dari
     * kedua channel pada tiap frekuensi gabungan (lewat interpolasi log).
     * Kalau hanya satu channel yang ada, kurva itu dipakai apa adanya.
     */
    fun mergeChannels(
        left: List<FrequencyPoint>?,
        right: List<FrequencyPoint>?,
    ): List<FrequencyPoint> {
        val l = left.orEmpty()
        val r = right.orEmpty()
        if (l.isEmpty()) return r
        if (r.isEmpty()) return l
        val freqs = (l.map { it.freqHz } + r.map { it.freqHz }).distinct().sorted()
        return freqs.map { f ->
            FrequencyPoint(f, (interpolateDb(l, f) + interpolateDb(r, f)) / 2.0)
        }
    }
}
