package com.srmusic.autoeq

/**
 * Parser JSON minimal (recursive descent) tanpa dependensi.
 *
 * Dipakai karena modul ini harus bisa di-compile dan di-test di JVM murni:
 * `org.json` hanya tersedia di framework Android, dan menambah Gson/Moshi
 * hanya untuk dua file JSON kecil adalah beban yang tidak perlu.
 * Hanya mendukung JSON standar; angka dibaca sebagai Double.
 */

sealed interface JsonValue {
    data class Obj(val map: Map<String, JsonValue>) : JsonValue
    data class Arr(val items: List<JsonValue>) : JsonValue
    data class Str(val value: String) : JsonValue
    data class Num(val value: Double) : JsonValue
    data class Bool(val value: Boolean) : JsonValue
    object Null : JsonValue
}

fun JsonValue.asObject(): Map<String, JsonValue> =
    (this as? JsonValue.Obj)?.map ?: throw IllegalArgumentException("bukan object JSON: $this")

fun JsonValue.asArray(): List<JsonValue> =
    (this as? JsonValue.Arr)?.items ?: throw IllegalArgumentException("bukan array JSON: $this")

fun JsonValue.asString(): String =
    (this as? JsonValue.Str)?.value ?: throw IllegalArgumentException("bukan string JSON: $this")

fun JsonValue.asStringOrNull(): String? = (this as? JsonValue.Str)?.value

fun JsonValue.asDoubleOrNull(): Double? = (this as? JsonValue.Num)?.value

object JsonParser {

    fun parse(text: String): JsonValue {
        val p = Parser(text)
        val v = p.value()
        p.skipWs()
        require(p.atEnd()) { "karakter berlebih setelah JSON pada offset ${p.pos}" }
        return v
    }

    private class Parser(private val s: String) {
        var pos = 0

        fun atEnd(): Boolean = pos >= s.length

        fun skipWs() {
            while (pos < s.length && s[pos].isWhitespace()) pos++
        }

        fun value(): JsonValue {
            skipWs()
            require(pos < s.length) { "JSON berakhir mendadak" }
            return when (val c = s[pos]) {
                '{' -> obj()
                '[' -> arr()
                '"' -> JsonValue.Str(str())
                't' -> literal("true", JsonValue.Bool(true))
                'f' -> literal("false", JsonValue.Bool(false))
                'n' -> literal("null", JsonValue.Null)
                else -> {
                    if (c == '-' || c.isDigit()) num() else
                        throw IllegalArgumentException("karakter JSON tak dikenal '$c' pada offset $pos")
                }
            }
        }

        private fun literal(word: String, v: JsonValue): JsonValue {
            require(s.startsWith(word, pos)) { "literal '$word' tidak lengkap pada offset $pos" }
            pos += word.length
            return v
        }

        private fun obj(): JsonValue.Obj {
            pos++ // {
            val map = LinkedHashMap<String, JsonValue>()
            skipWs()
            if (pos < s.length && s[pos] == '}') {
                pos++
                return JsonValue.Obj(map)
            }
            while (true) {
                skipWs()
                val key = str()
                skipWs()
                require(pos < s.length && s[pos] == ':') { "':' diharapkan pada offset $pos" }
                pos++
                map[key] = value()
                skipWs()
                when {
                    pos < s.length && s[pos] == ',' -> pos++
                    pos < s.length && s[pos] == '}' -> {
                        pos++
                        return JsonValue.Obj(map)
                    }
                    else -> throw IllegalArgumentException("',' atau '}' diharapkan pada offset $pos")
                }
            }
        }

        private fun arr(): JsonValue.Arr {
            pos++ // [
            val items = ArrayList<JsonValue>()
            skipWs()
            if (pos < s.length && s[pos] == ']') {
                pos++
                return JsonValue.Arr(items)
            }
            while (true) {
                items += value()
                skipWs()
                when {
                    pos < s.length && s[pos] == ',' -> pos++
                    pos < s.length && s[pos] == ']' -> {
                        pos++
                        return JsonValue.Arr(items)
                    }
                    else -> throw IllegalArgumentException("',' atau ']' diharapkan pada offset $pos")
                }
            }
        }

        private fun str(): String {
            require(pos < s.length && s[pos] == '"') { "'\"' diharapkan pada offset $pos" }
            pos++
            val sb = StringBuilder()
            while (pos < s.length) {
                when (val c = s[pos++]) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        require(pos < s.length) { "escape JSON tidak lengkap" }
                        when (val e = s[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                require(pos + 4 <= s.length) { "escape \\u tidak lengkap" }
                                sb.append(s.substring(pos, pos + 4).toInt(16).toChar())
                                pos += 4
                            }
                            else -> throw IllegalArgumentException("escape JSON '\\$e' tidak dikenal")
                        }
                    }
                    else -> sb.append(c)
                }
            }
            throw IllegalArgumentException("string JSON tidak ditutup")
        }

        private fun num(): JsonValue.Num {
            val start = pos
            if (pos < s.length && s[pos] == '-') pos++
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.' || s[pos] == 'e' ||
                        s[pos] == 'E' || s[pos] == '+' || s[pos] == '-')
            ) pos++
            val text = s.substring(start, pos)
            return JsonValue.Num(
                text.toDoubleOrNull()
                    ?: throw IllegalArgumentException("angka JSON tidak valid: '$text'"),
            )
        }
    }
}
