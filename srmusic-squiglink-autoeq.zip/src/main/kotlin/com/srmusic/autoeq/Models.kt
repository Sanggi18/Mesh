package com.srmusic.autoeq

/**
 * Model data untuk modul AutoEq squig.link.
 *
 * Semua model murni Kotlin (tanpa dependensi Android) supaya bisa di-unit-test
 * di JVM dan dipakai ulang di layer manapun.
 */

/** Satu database pengukuran milik seorang reviewer di squig.link. */
data class SquigDb(
    /** "IEMs" atau "Headphones". */
    val type: String,
    /** Folder di bawah host reviewer, "/" untuk IEMs, "/headphones/" untuk headphone. */
    val folder: String,
)

/** Satu situs reviewer dari `https://squig.link/squigsites.json`. */
data class SquigSite(
    val name: String,
    /** Username = subdomain, mis. "harpo" -> https://harpo.squig.link */
    val username: String,
    val dbs: List<SquigDb>,
)

/**
 * Satu IEM/headphone di dalam `phone_book.json`.
 *
 * `files` bisa berisi lebih dari satu nama file (mis. varian nozzle/mode dari
 * satu model) — di phone_book.json field `file` kadang string, kadang list.
 */
data class IemEntry(
    val name: String,
    val files: List<String>,
    val reviewScore: String? = null,
    val reviewLink: String? = null,
    val price: String? = null,
    val shopLink: String? = null,
)

/** Satu section di dalam `phone_book.json` (mis. berdasarkan brand). */
data class PhoneBookSection(
    val name: String,
    val phones: List<IemEntry>,
)

/** Satu titik kurva: frekuensi (Hz) dan level (dB). */
data class FrequencyPoint(
    val freqHz: Double,
    val db: Double,
)

/** Kurva respons frekuensi, selalu terurut naik berdasarkan frekuensi. */
data class FrequencyResponse(
    val points: List<FrequencyPoint>,
) {
    init {
        require(points.zipWithNext().all { (a, b) -> a.freqHz < b.freqHz }) {
            "FrequencyResponse points harus terurut naik dan unik"
        }
    }
}

/** Jenis filter parametrik yang didukung fitter dan prosesor biquad. */
enum class FilterKind {
    PEAKING,
    LOW_SHELF,
    HIGH_SHELF,
}

/** Satu filter parametrik: jenis, frekuensi tengah, gain, dan Q. */
data class ParametricFilter(
    val kind: FilterKind,
    val freqHz: Double,
    val gainDb: Double,
    val q: Double,
)

/**
 * Profil PEQ hasil fit untuk satu IEM.
 *
 * `preampDb` selalu <= 0: pengurang gain global supaya respons gabungan
 * tidak clipping. Terapkan sebagai pengali `10^(preampDb / 20)`.
 */
data class PeqProfile(
    val iemName: String,
    /** Nama sumber pengukuran, mis. "Harpo" (dari squigsites.json). */
    val source: String,
    /** Rig pengukuran, mis. "711" (IEC 60318-4). */
    val rig: String,
    val targetName: String,
    val preampDb: Double,
    val filters: List<ParametricFilter>,
)

/** Kurva target (mis. Harman IE 2019), titik-titiknya terurut naik. */
data class TargetCurve(
    val name: String,
    val points: List<FrequencyPoint>,
)
