package com.srmusic.autoeq

import java.io.File

/**
 * Penyimpanan profil PEQ hasil fit, satu file JSON per (perangkat output, IEM).
 *
 * Disimpan supaya profil tidak perlu di-fit ulang tiap buka aplikasi:
 * fetch FR + fit hanya terjadi sekali per IEM (atau saat user minta refresh).
 * JSON ditulis/dibaca manual (tanpa library serialisasi) supaya modul tetap
 * tanpa dependensi dan bisa di-test di JVM.
 *
 * Format file:
 * ```json
 * {"iemName":"...","source":"Harpo","rig":"711","targetName":"harman_in-ear_2019",
 *  "preampDb":-3.5,
 *  "filters":[{"kind":"LOW_SHELF","freqHz":31.0,"gainDb":4.2,"q":1.0}, ...]}
 * ```
 */
class PeqProfileStore(private val dir: File) {

    fun save(deviceKey: String, iemId: String, profile: PeqProfile) {
        val file = fileFor(deviceKey, iemId)
        file.parentFile?.mkdirs()
        file.writeText(toJson(profile), Charsets.UTF_8)
    }

    /** Null bila tidak ada file atau isinya rusak. */
    fun load(deviceKey: String, iemId: String): PeqProfile? {
        val file = fileFor(deviceKey, iemId)
        if (!file.isFile) return null
        return try {
            fromJson(file.readText(Charsets.UTF_8))
        } catch (_: Exception) {
            null
        }
    }

    fun delete(deviceKey: String, iemId: String): Boolean = fileFor(deviceKey, iemId).delete()

    /**
     * Daftar kunci tersimpan sebagai pasangan (deviceKey, iemId).
     * Kunci dikembalikan dalam bentuk yang sudah disanitasi untuk nama file.
     */
    fun listSaved(): List<Pair<String, String>> {
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".json") } ?: return emptyList()
        return files.mapNotNull { f ->
            val base = f.name.removeSuffix(".json").split("__")
            if (base.size == 2) base[0] to base[1] else null
        }
    }

    fun fileFor(deviceKey: String, iemId: String): File =
        File(dir, "${sanitize(deviceKey)}__${sanitize(iemId)}.json")

    companion object {
        fun toJson(profile: PeqProfile): String {
            val sb = StringBuilder()
            sb.append("{")
            sb.append("\"iemName\":").append(quote(profile.iemName)).append(",")
            sb.append("\"source\":").append(quote(profile.source)).append(",")
            sb.append("\"rig\":").append(quote(profile.rig)).append(",")
            sb.append("\"targetName\":").append(quote(profile.targetName)).append(",")
            sb.append("\"preampDb\":").append(profile.preampDb).append(",")
            sb.append("\"filters\":[")
            profile.filters.forEachIndexed { i, f ->
                if (i > 0) sb.append(",")
                sb.append("{\"kind\":").append(quote(f.kind.name)).append(",")
                sb.append("\"freqHz\":").append(f.freqHz).append(",")
                sb.append("\"gainDb\":").append(f.gainDb).append(",")
                sb.append("\"q\":").append(f.q).append("}")
            }
            sb.append("]}")
            return sb.toString()
        }

        fun fromJson(text: String): PeqProfile? {
            return try {
                val obj = JsonParser.parse(text).asObject()
                val filters = obj["filters"]?.asArray().orEmpty().map { item ->
                    val fo = item.asObject()
                    ParametricFilter(
                        kind = FilterKind.valueOf(
                            fo["kind"]?.asStringOrNull() ?: "PEAKING",
                        ),
                        freqHz = fo["freqHz"]?.asDoubleOrNull() ?: 0.0,
                        gainDb = fo["gainDb"]?.asDoubleOrNull() ?: 0.0,
                        q = fo["q"]?.asDoubleOrNull() ?: 1.0,
                    )
                }
                PeqProfile(
                    iemName = obj["iemName"]?.asStringOrNull() ?: return null,
                    source = obj["source"]?.asStringOrNull() ?: "",
                    rig = obj["rig"]?.asStringOrNull() ?: "",
                    targetName = obj["targetName"]?.asStringOrNull() ?: "",
                    preampDb = obj["preampDb"]?.asDoubleOrNull() ?: 0.0,
                    filters = filters,
                )
            } catch (_: Exception) {
                null
            }
        }

        private fun quote(s: String): String {
            val sb = StringBuilder("\"")
            for (c in s) {
                when (c) {
                    '"' -> sb.append("\\\"")
                    '\\' -> sb.append("\\\\")
                    '\n' -> sb.append("\\n")
                    '\r' -> sb.append("\\r")
                    '\t' -> sb.append("\\t")
                    else -> if (c < ' ') sb.append("\\u%04x".format(c.code)) else sb.append(c)
                }
            }
            return sb.append("\"").toString()
        }

        private fun sanitize(name: String): String =
            name.replace(Regex("[^A-Za-z0-9._-]+"), "_").take(120)
    }
}
