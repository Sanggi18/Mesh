package com.srmusic.autoeq

import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Client squig.link — fetch langsung dari server, tanpa API key.
 *
 * Rantai URL (diverifikasi live 2026-11-20, pola dari crawler resmi AutoEq
 * `dbtools/squig_crawler.py`):
 * 1. `GET https://squig.link/squigsites.json` -> 125 situs reviewer.
 * 2. `GET https://<username>.squig.link<folder>data/phone_book.json`
 *    -> daftar IEM (folder "/" untuk IEMs, "/headphones/" untuk headphone).
 * 3. `GET https://<username>.squig.link<folder>data/<file> L.txt` dan
 *    `... R.txt` (URL-encoded) -> FR mentah format REW.
 *
 * Header User-Agent browser WAJIB dikirim (cara crawler AutoEq); tanpa itu
 * server bisa menolak. Semua respons di-cache di [cacheDir] selama
 * [cacheMaxAgeMs] (default 24 jam) supaya daftar IEM tidak di-fetch ulang
 * tiap buka picker.
 *
 * Semua fungsi ini blocking (network I/O) — panggil dari thread background
 * (di Android: `Dispatchers.IO`). Tidak ada dependensi HTTP eksternal:
 * [HttpURLConnection] bawaan JDK/Android sudah cukup.
 */
open class SquigLinkClient(
    private val cacheDir: File,
    private val cacheMaxAgeMs: Long = DEFAULT_CACHE_MAX_AGE_MS,
    private val userAgent: String = DEFAULT_USER_AGENT,
    private val baseUrl: String = "https://squig.link",
    private val connectTimeoutMs: Int = 15_000,
    private val readTimeoutMs: Int = 30_000,
) {
    companion object {
        const val DEFAULT_CACHE_MAX_AGE_MS: Long = 24L * 3600L * 1000L
        const val DEFAULT_USER_AGENT: String =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0"

        /**
         * Rig pengukuran per reviewer (dari `_squig_rigs` di
         * `dbtools/squig_crawler.py` AutoEq). Dipakai sebagai metadata profil;
         * rig yang tidak dikenal dilaporkan "unknown" — hasil ukur antar rig
         * memang tidak bisa dibandingkan langsung.
         */
        val KNOWN_RIGS: Map<String, Map<String, String>> = mapOf(
            "Auriculares Argentina" to mapOf("in-ear" to "711", "over-ear" to "KB501x + 711"),
            "Bakkwatan" to mapOf("in-ear" to "711"),
            "DHRME" to mapOf("in-ear" to "711"),
            "Fahryst" to mapOf("in-ear" to "711"),
            "Filk" to mapOf("in-ear" to "711", "over-ear" to "KB006x + 711"),
            "freeryder05" to mapOf("in-ear" to "711"),
            "Harpo" to mapOf("in-ear" to "711"),
            "Hi End Portable" to mapOf("in-ear" to "711"),
            "Jaytiss" to mapOf("in-ear" to "711"),
            "Kazi" to mapOf("in-ear" to "711"),
            "kr0mka" to mapOf("in-ear" to "711", "over-ear" to "KB501x + 711"),
            "Kuulokenurkka" to mapOf("in-ear" to "711", "over-ear" to "KB501x + 711"),
            "Regan Cipher" to mapOf("in-ear" to "711", "over-ear" to "KB500x + 711"),
            "RikudouGoku" to mapOf("in-ear" to "711"),
            "Super Review" to mapOf("in-ear" to "711", "over-ear" to "KB006x + 711"),
            "Ted's Squig Hoard" to mapOf("in-ear" to "711", "over-ear" to "KB500x + 711"),
            "ToneDeafMonk" to mapOf("in-ear" to "711"),
        )

        fun rigFor(siteName: String, form: String): String =
            KNOWN_RIGS[siteName]?.get(form) ?: "unknown"
    }

    /** Hasil fetch FR: kurva gabungan + channel mana yang berhasil diambil. */
    data class FrFetchResult(
        val response: FrequencyResponse,
        /** "L" dan/atau "R". Kosong tidak mungkin (fetch gagal -> exception). */
        val channels: Set<String>,
    )

    // ------------------------------------------------------------------ URL

    fun sitesUrl(): String = "$baseUrl/squigsites.json"

    /** Base URL satu situs reviewer; open supaya test bisa mengarahkan ke server lokal. */
    protected open fun siteBaseUrl(site: SquigSite): String =
        "https://${site.username}.squig.link"

    open fun phoneBookUrl(site: SquigSite, db: SquigDb): String =
        "${siteBaseUrl(site)}${db.folder}data/phone_book.json"

    open fun frUrl(site: SquigSite, db: SquigDb, file: String, channel: String): String {
        val encoded = URLEncoder.encode("$file $channel.txt", "UTF-8").replace("+", "%20")
        return "${siteBaseUrl(site)}${db.folder}data/$encoded"
    }

    // ------------------------------------------------------------------ API

    /** Daftar semua situs reviewer. */
    @Throws(SquigLinkException::class)
    fun fetchSites(): List<SquigSite> {
        val text = getCached("sites.json", sitesUrl())
        val root = JsonParser.parse(text).asArray()
        return root.map { item ->
            val obj = item.asObject()
            val dbs = obj["dbs"]?.asArray().orEmpty().map { d ->
                val dd = d.asObject()
                SquigDb(
                    type = dd["type"]?.asStringOrNull() ?: "IEMs",
                    folder = dd["folder"]?.asStringOrNull() ?: "/",
                )
            }
            SquigSite(
                name = obj["name"]?.asStringOrNull() ?: "?",
                username = obj["username"]?.asStringOrNull()
                    ?: throw SquigLinkException("squigsites.json: site tanpa username"),
                dbs = dbs,
            )
        }
    }

    /** Daftar IEM/headphone satu database reviewer. */
    @Throws(SquigLinkException::class)
    fun fetchPhoneBook(site: SquigSite, db: SquigDb): List<PhoneBookSection> {
        val cacheName = "phonebook_${sanitize(site.username)}_${sanitize(db.type)}.json"
        val text = getCached(cacheName, phoneBookUrl(site, db))
        val root = JsonParser.parse(text).asArray()
        return root.map { section ->
            val obj = section.asObject()
            val phones = obj["phones"]?.asArray().orEmpty().mapNotNull { p ->
                val po = p.asObject()
                val name = po["name"]?.asStringOrNull() ?: return@mapNotNull null
                val fileRaw = po["file"] ?: return@mapNotNull null
                val files: List<String> = when (fileRaw) {
                    is JsonValue.Str -> listOf(fileRaw.value)
                    is JsonValue.Arr -> fileRaw.items.mapNotNull { it.asStringOrNull() }
                    else -> emptyList()
                }
                if (files.isEmpty()) return@mapNotNull null
                IemEntry(
                    name = name,
                    files = files,
                    reviewScore = po["reviewScore"]?.asStringOrNull(),
                    reviewLink = po["reviewLink"]?.asStringOrNull(),
                    price = po["price"]?.asStringOrNull(),
                    shopLink = po["shopLink"]?.asStringOrNull(),
                )
            }
            PhoneBookSection(
                name = obj["name"]?.asStringOrNull() ?: "",
                phones = phones,
            )
        }
    }

    /**
     * Ambil FR satu file IEM. Mencoba channel L lalu R; kalau dua-duanya ada,
     * digabung (rata-rata dB). Kalau hanya satu yang ada, itu yang dipakai.
     * Gagal total (dua-duanya 404/error) -> [SquigLinkException].
     */
    @Throws(SquigLinkException::class)
    fun fetchFr(site: SquigSite, db: SquigDb, file: String): FrFetchResult {
        var left: List<FrequencyPoint>? = null
        var right: List<FrequencyPoint>? = null
        var lastError: SquigLinkException? = null
        for (channel in listOf("L", "R")) {
            val cacheName =
                "fr_${sanitize(site.username)}_${sanitize(db.type)}_${sanitize(file)}_$channel.txt"
            val text = try {
                getCached(cacheName, frUrl(site, db, file, channel))
            } catch (e: SquigLinkException) {
                lastError = e
                null
            } ?: continue
            val points = FrParser.parse(text)
            if (points.size < 2) continue
            if (channel == "L") left = points else right = points
        }
        if (left == null && right == null) {
            throw lastError
                ?: SquigLinkException("FR '$file' tidak ditemukan (L/R) di ${site.username}")
        }
        val merged = FrParser.mergeChannels(left, right)
        val channels = buildSet {
            if (left != null) add("L")
            if (right != null) add("R")
        }
        return FrFetchResult(FrequencyResponse(merged), channels)
    }

    // ------------------------------------------------------------------ I/O

    /**
     * GET dengan cache berbasis umur: kalau file cache masih segar, isi cache
     * yang dipakai tanpa network. File cache ditulis sebagai teks UTF-8.
     */
    @Throws(SquigLinkException::class)
    fun getCached(cacheName: String, url: String): String {
        val file = File(cacheDir, sanitize(cacheName))
        if (file.isFile && System.currentTimeMillis() - file.lastModified() < cacheMaxAgeMs) {
            try {
                return file.readText(Charsets.UTF_8)
            } catch (_: Exception) {
                // Cache rusak -> fetch ulang di bawah.
            }
        }
        val text = httpGet(url)
        try {
            file.parentFile?.mkdirs()
            file.writeText(text, Charsets.UTF_8)
        } catch (_: Exception) {
            // Gagal menulis cache bukan error fatal: kembalikan hasil fetch.
        }
        return text
    }

    /** GET mentah via HttpURLConnection. 404/HTTP error -> SquigLinkException. */
    @Throws(SquigLinkException::class)
    open fun httpGet(url: String): String {
        val conn = try {
            (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", userAgent)
                setRequestProperty("Accept", "application/json, text/plain, */*")
                connectTimeout = connectTimeoutMs
                readTimeout = readTimeoutMs
                instanceFollowRedirects = true
            }
        } catch (e: Exception) {
            throw SquigLinkException("gagal membuka $url: ${e.message}", e)
        }
        try {
            val code = try {
                conn.responseCode
            } catch (e: Exception) {
                throw SquigLinkException("gagal membaca $url: ${e.message}", e)
            }
            if (code != HttpURLConnection.HTTP_OK) {
                throw SquigLinkException("HTTP $code untuk $url")
            }
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun sanitize(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]+"), "_").take(180)
}

/** Error jaringan/parsing squig.link (termasuk HTTP 404 pada file FR). */
class SquigLinkException(message: String, cause: Throwable? = null) : Exception(message, cause)
