package com.srmusic.autoeq

/**
 * Kurva target yang dibundel bersama modul (di `src/main/assets/targets/`).
 *
 * - Harman IE 2019: dari repo jaakkopasanen/AutoEq (MIT),
 *   `targets/Harman in-ear 2019.csv`. Ini target default.
 * - Super 22: target milik Super* Review, dari
 *   `https://squig.link/data/Super%2022%20Target.txt` (CC BY 4.0),
 *   dikonversi ke CSV dua kolom.
 *
 * Target lain bisa ditambah dengan cara yang sama: file dua kolom
 * `freq,dB` (atau format REW `freq<TAB>dB`) ditaruh di folder asset dan
 * didaftarkan di [BUILT_IN]. JM-1 tidak dibundel karena file
 * `JM-1 Target.txt` tidak ditemukan di direktori data squig.link saat
 * modul ini dibuat (dicoba 2026-11-20, 404).
 */
object TargetCurves {

    const val HARMAN_IN_EAR_2019 = "harman_in-ear_2019"
    const val SUPER_22 = "super_22"

    /** Nama file asset per target. */
    val BUILT_IN: Map<String, String> = mapOf(
        HARMAN_IN_EAR_2019 to "targets/harman_in-ear_2019.csv",
        SUPER_22 to "targets/super_22.csv",
    )

    /** Parse isi file target (CSV `frequency,raw` atau teks REW) menjadi kurva. */
    fun parse(name: String, text: String): TargetCurve {
        val points = FrParser.parse(text)
        require(points.size >= 2) { "target '$name' tidak punya cukup titik" }
        return TargetCurve(name, points)
    }

    /**
     * Muat target bawaan. [readAsset] disediakan pemanggil karena modul ini
     * tidak tahu dari mana asset dibaca: di Android, `{ context.assets.open(p).bufferedReader().readText() }`;
     * di test JVM, baca dari classpath/resources.
     */
    fun loadBuiltIn(name: String, readAsset: (String) -> String?): TargetCurve? {
        val asset = BUILT_IN[name] ?: return null
        val text = readAsset(asset) ?: return null
        return parse(name, text)
    }
}
