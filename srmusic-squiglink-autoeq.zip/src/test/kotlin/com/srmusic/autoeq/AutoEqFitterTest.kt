package com.srmusic.autoeq

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoEqFitterTest {

    private fun loadFr(): FrequencyResponse {
        val text = javaClass.classLoader
            .getResourceAsStream("7hz_eternal_R.txt")!!.bufferedReader().readText()
        return FrequencyResponse(FrParser.parse(text))
    }

    private fun loadHarman(): TargetCurve {
        val text = File("src/main/assets/targets/harman_in-ear_2019.csv").readText()
        return TargetCurves.parse(TargetCurves.HARMAN_IN_EAR_2019, text)
    }

    @Test
    fun `fit FR asli melawan Harman IE 2019`() {
        val profile = AutoEqFitter.fit(loadFr(), loadHarman(), "7Hz Eternal", "Harpo", "711")
        assertEquals("7Hz Eternal", profile.iemName)
        assertEquals("Harpo", profile.source)
        assertEquals("711", profile.rig)
        assertEquals(10, profile.filters.size)
        // Band 1 low shelf, band 10 high shelf, sisanya peaking.
        assertEquals(FilterKind.LOW_SHELF, profile.filters.first().kind)
        assertEquals(FilterKind.HIGH_SHELF, profile.filters.last().kind)
        assertTrue(profile.filters.subList(1, 9).all { it.kind == FilterKind.PEAKING })
        // Frekuensi band persis seperti yang ditentukan.
        val freqs = profile.filters.map { it.freqHz }
        assertEquals(
            listOf(31.0, 62.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0),
            freqs,
        )
        // Semua gain dalam batas, Q = 1.0, preamp tidak positif.
        assertTrue(profile.filters.all { it.gainDb in -12.0..12.0 })
        assertTrue(profile.filters.all { it.q == 1.0 })
        assertTrue("preamp ${profile.preampDb}", profile.preampDb <= 0.0)
        // Preamp tidak boleh membengkak: kalau fit mengejar ujung treble
        // yang tidak bisa dipercaya, preamp akan jatuh ke < -8 dB.
        assertTrue("preamp ${profile.preampDb}", profile.preampDb >= -8.0)
        // Profil tidak boleh kosong: ada koreksi yang nyata.
        assertTrue(profile.filters.any { kotlin.math.abs(it.gainDb) > 1.0 })
    }

    @Test
    fun `residual fit dalam toleransi`() {
        val fr = loadFr()
        val target = loadHarman()
        val profile = AutoEqFitter.fit(fr, target, "7Hz Eternal", "Harpo", "711")
        val residuals = AutoEqFitter.residuals(profile, fr, target)
        assertEquals(10, residuals.size)
        val meanAbs = residuals.map { kotlin.math.abs(it) }.average()
        val maxAbs = residuals.map { kotlin.math.abs(it) }.max()
        // Toleransi yang didokumentasikan (diukur pada fixture ini):
        // fit iteratif fixed-frequency bukan least-squares penuh, jadi
        // residual tidak nol — tapi harus jauh lebih kecil dari error awal.
        println("residual per band: " + residuals.joinToString(", ") { "%.2f".format(it) })
        println("meanAbs=%.3f maxAbs=%.3f".format(meanAbs, maxAbs))
        assertTrue("meanAbs residual $meanAbs", meanAbs < 2.0)
        assertTrue("maxAbs residual $maxAbs", maxAbs < 4.0)
    }

    @Test
    fun `fit FR sama dengan target menghasilkan profil datar`() {
        val target = loadHarman()
        val flatFr = FrequencyResponse(target.points)
        val profile = AutoEqFitter.fit(flatFr, target, "X", "Test", "711")
        assertTrue(profile.filters.all { kotlin.math.abs(it.gainDb) < 0.05 })
        assertEquals(0.0, profile.preampDb, 0.05)
    }
}
