package com.srmusic.autoeq

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BiquadAudioProcessorTest {

    private fun floatFormat() =
        AudioProcessor.AudioFormat(48_000, 2, C.ENCODING_PCM_FLOAT)

    private fun floatBuffer(vararg samples: Float): ByteBuffer {
        val buf = ByteBuffer.allocateDirect(samples.size * 4).order(ByteOrder.nativeOrder())
        for (s in samples) buf.putFloat(s)
        buf.flip()
        return buf
    }

    private fun drainAll(p: BiquadAudioProcessor): FloatArray {
        val out = p.output
        val arr = FloatArray(out.remaining() / 4)
        out.order(ByteOrder.nativeOrder())
        for (i in arr.indices) arr[i] = out.getFloat()
        return arr
    }

    private fun profilePlus6At1k(): PeqProfile = PeqProfile(
        iemName = "Test",
        source = "Test",
        rig = "711",
        targetName = "harman",
        preampDb = 0.0,
        filters = listOf(ParametricFilter(FilterKind.PEAKING, 1000.0, 6.0, 1.0)),
    )

    @Test
    fun `tanpa profil prosesor tidak aktif`() {
        val p = BiquadAudioProcessor()
        p.configure(floatFormat())
        assertFalse(p.isActive)
        p.queueInput(floatBuffer(0.5f, 0.5f))
        assertEquals(0, p.output.remaining())
    }

    @Test
    fun `dengan profil prosesor aktif dan menguatkan sine 1 kHz`() {
        val p = BiquadAudioProcessor()
        p.setProfile(profilePlus6At1k())
        p.configure(floatFormat())
        assertTrue(p.isActive)

        val n = 4800 // 100 ms @48k, stereo
        val buf = ByteBuffer.allocateDirect(n * 2 * 4).order(ByteOrder.nativeOrder())
        for (i in 0 until n) {
            val s = (0.5 * sin(2.0 * PI * 1000.0 * i / 48_000.0)).toFloat()
            buf.putFloat(s)
            buf.putFloat(s)
        }
        buf.flip()
        p.queueInput(buf)
        val out = drainAll(p)
        assertEquals(n * 2, out.size)
        // RMS paruh kedua (setelah transient) ~2x input.
        var sumIn = 0.0
        var sumOut = 0.0
        for (i in n until n * 2) {
            val s = 0.5 * sin(2.0 * PI * 1000.0 * (i - n) / 48_000.0)
            sumIn += s * s
            sumOut += out[i].toDouble() * out[i].toDouble()
        }
        val ratio = kotlin.math.sqrt(sumOut / sumIn)
        assertEquals(2.0, ratio, 0.15)
    }

    @Test
    fun `bit-perfect mematikan prosesor`() {
        val p = BiquadAudioProcessor()
        p.setProfile(profilePlus6At1k())
        p.configure(floatFormat())
        assertTrue(p.isActive)
        p.setBitPerfect(true)
        assertFalse(p.isActive)
        p.queueInput(floatBuffer(0.5f, 0.5f))
        assertEquals(0, p.output.remaining())
    }

    @Test
    fun `profil nol tetap aktif tapi sinyal tidak berubah`() {
        val p = BiquadAudioProcessor()
        p.setProfile(
            PeqProfile("T", "T", "711", "harman", 0.0, listOf(
                ParametricFilter(FilterKind.PEAKING, 1000.0, 0.0, 1.0),
            )),
        )
        p.configure(floatFormat())
        assertTrue(p.isActive)
        p.queueInput(floatBuffer(0.25f, -0.75f, 0.5f, 0.125f))
        val out = drainAll(p)
        assertEquals(0.25f, out[0], 0.0f)
        assertEquals(-0.75f, out[1], 0.0f)
        assertEquals(0.5f, out[2], 0.0f)
        assertEquals(0.125f, out[3], 0.0f)
    }

    @Test
    fun `jalur 16-bit round trip`() {
        val p = BiquadAudioProcessor()
        p.setProfile(
            PeqProfile("T", "T", "711", "harman", 0.0, listOf(
                ParametricFilter(FilterKind.PEAKING, 1000.0, 0.0, 1.0),
            )),
        )
        val format = AudioProcessor.AudioFormat(48_000, 2, C.ENCODING_PCM_16BIT)
        p.configure(format)
        assertTrue(p.isActive)
        val buf = ByteBuffer.allocateDirect(4 * 2).order(ByteOrder.nativeOrder())
        buf.putShort(16384).putShort(-16384).putShort(8192).putShort(-8192)
        buf.flip()
        p.queueInput(buf)
        val out = p.output.order(ByteOrder.nativeOrder())
        // Skala 16-bit memakai 32767 (standar): 16384/32768*32767 = 16383,5
        // -> truncate jadi 16383. Toleransi ±1 LSB adalah perilaku yang benar.
        assertTrue(kotlin.math.abs(out.getShort() - 16384) <= 1)
        assertTrue(kotlin.math.abs(out.getShort() - -16384) <= 1)
        // 8192/32768 -> proses -> *32767: pembulatan ±1 LSB wajar.
        assertTrue(kotlin.math.abs(out.getShort() - 8192) <= 1)
        assertTrue(kotlin.math.abs(out.getShort() - -8192) <= 1)
    }

    @Test
    fun `format tidak didukung ditolak saat configure`() {
        val p = BiquadAudioProcessor()
        var threw = false
        try {
            p.configure(AudioProcessor.AudioFormat(48_000, 2, C.ENCODING_PCM_24BIT))
        } catch (_: AudioProcessor.UnhandledAudioFormatException) {
            threw = true
        }
        assertTrue(threw)
    }

    @Test
    fun `flush mereset state filter`() {
        val p = BiquadAudioProcessor()
        p.setProfile(profilePlus6At1k())
        p.configure(floatFormat())
        // Impuls: keluarkan ekor filter, lalu flush, lalu nol harus tetap nol.
        p.queueInput(floatBuffer(1.0f, 1.0f))
        drainAll(p)
        p.flush()
        p.queueInput(floatBuffer(0.0f, 0.0f, 0.0f, 0.0f))
        val out = drainAll(p)
        assertTrue(out.all { it == 0.0f })
    }
}
