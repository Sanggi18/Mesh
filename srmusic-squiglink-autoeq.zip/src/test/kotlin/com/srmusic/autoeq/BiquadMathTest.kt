package com.srmusic.autoeq

import kotlin.math.PI
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BiquadMathTest {

    private val fs = 48_000.0

    @Test
    fun `gain nol menghasilkan respons 0 dB`() {
        val flat = List(10) { i ->
            ParametricFilter(FilterKind.PEAKING, AutoEqFitter.BAND_FREQS[i], 0.0, 1.0)
        }
        for (f in listOf(20.0, 100.0, 1000.0, 8000.0, 20000.0)) {
            assertEquals(0.0, BiquadMath.combinedDb(flat, f, fs), 1e-9)
        }
    }

    @Test
    fun `peaking plus 6 dB tepat di frekuensi tengah`() {
        val filter = ParametricFilter(FilterKind.PEAKING, 1000.0, 6.0, 1.0)
        val coeffs = BiquadMath.coefficients(filter, fs)
        assertEquals(6.0, BiquadMath.responseDb(coeffs, 1000.0, fs), 0.01)
        // Jauh dari tengah, respons kembali mendekati 0.
        assertTrue(kotlin.math.abs(BiquadMath.responseDb(coeffs, 100.0, fs)) < 0.5)
        assertTrue(kotlin.math.abs(BiquadMath.responseDb(coeffs, 10000.0, fs)) < 0.5)
    }

    @Test
    fun `low shelf mencapai gain penuh di bawah fc`() {
        val coeffs = BiquadMath.coefficients(
            ParametricFilter(FilterKind.LOW_SHELF, 100.0, 6.0, 1.0), fs,
        )
        assertEquals(6.0, BiquadMath.responseDb(coeffs, 20.0, fs), 0.15)
        assertTrue(kotlin.math.abs(BiquadMath.responseDb(coeffs, 5000.0, fs)) < 0.05)
        // Di fc, shelf hanya ~setengah gain (ini alasan shelf dievaluasi
        // di 20 Hz / 20 kHz saat fitting, bukan di fc).
        // Toleransi 0,15 dB: rumus shelf berbasis Q sedikit overshoot
        // di atas gain nominal (sama seperti PeqMath.kt dac-control).
        assertEquals(3.0, BiquadMath.responseDb(coeffs, 100.0, fs), 0.15)
    }

    @Test
    fun `high shelf mencapai gain penuh di atas fc`() {
        val coeffs = BiquadMath.coefficients(
            ParametricFilter(FilterKind.HIGH_SHELF, 8000.0, -6.0, 1.0), fs,
        )
        assertEquals(-6.0, BiquadMath.responseDb(coeffs, 20000.0, fs), 0.15)
        assertTrue(kotlin.math.abs(BiquadMath.responseDb(coeffs, 100.0, fs)) < 0.05)
    }

    @Test
    fun `sine 1 kHz dikuatkan peaking plus 6 dB`() {
        val chain = BiquadChain(1)
        chain.setFilters(
            listOf(ParametricFilter(FilterKind.PEAKING, 1000.0, 6.0, 1.0)),
            fs,
        )
        val n = 4800
        val frame = FloatArray(1)
        var sumIn = 0.0
        var sumOut = 0.0
        for (i in 0 until n) {
            val s = (0.5 * sin(2.0 * PI * 1000.0 * i / fs)).toFloat()
            frame[0] = s
            chain.processFrame(frame)
            if (i >= n / 2) {
                sumIn += s * s
                sumOut += frame[0] * frame[0]
            }
        }
        val ratio = kotlin.math.sqrt(sumOut / sumIn)
        // +6 dB = 2x amplitudo (toleransi 5% untuk transient awal).
        assertEquals(2.0, ratio, 0.1)
    }

    @Test
    fun `filter gain nol bit-identical`() {
        val chain = BiquadChain(2)
        chain.setFilters(
            listOf(ParametricFilter(FilterKind.PEAKING, 1000.0, 0.0, 1.0)),
            fs,
        )
        val frame = floatArrayOf(0.123456f, -0.654321f)
        val before = frame.copyOf()
        repeat(100) { chain.processFrame(frame) }
        assertEquals(before[0], frame[0], 0.0f)
        assertEquals(before[1], frame[1], 0.0f)
    }

    @Test
    fun `chain stereo channel tidak tercampur`() {
        val chain = BiquadChain(2)
        chain.setFilters(
            listOf(ParametricFilter(FilterKind.PEAKING, 1000.0, 6.0, 1.0)),
            fs,
        )
        // Kiri sine 1 kHz, kanan diam: kanan harus tetap 0.
        val frame = FloatArray(2)
        for (i in 0 until 4800) {
            frame[0] = (0.5 * sin(2.0 * PI * 1000.0 * i / fs)).toFloat()
            frame[1] = 0.0f
            chain.processFrame(frame)
            assertEquals(0.0f, frame[1], 0.0f)
        }
        assertTrue(kotlin.math.abs(frame[0]) > 0.1f)
    }
}
