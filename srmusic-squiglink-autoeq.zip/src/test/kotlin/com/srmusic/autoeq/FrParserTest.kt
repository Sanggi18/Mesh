package com.srmusic.autoeq

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FrParserTest {

    private fun resource(name: String): String =
        javaClass.classLoader.getResourceAsStream(name)!!.bufferedReader().readText()

    @Test
    fun `parse file FR asli 7Hz Eternal R`() {
        val points = FrParser.parse(resource("7hz_eternal_R.txt"))
        // File REW 493 baris: 15 baris komentar + 1 header + 477 data.
        assertTrue("jumlah titik: ${points.size}", points.size in 400..500)
        assertEquals(20.3, points.first().freqHz, 0.1)
        assertTrue(points.last().freqHz > 19000.0)
        assertTrue(points.all { it.db.isFinite() && it.db > -60.0 && it.db < 140.0 })
        assertTrue(points.zipWithNext().all { (a, b) -> a.freqHz < b.freqHz })
    }

    @Test
    fun `parse CSV dua kolom ala AutoEq`() {
        val points = FrParser.parse("frequency,raw\n20.00,7.61\n20.20,7.62\n20000.00,-20.61\n")
        assertEquals(3, points.size)
        assertEquals(20.0, points[0].freqHz, 1e-9)
        assertEquals(7.61, points[0].db, 1e-9)
        assertEquals(-20.61, points[2].db, 1e-9)
    }

    @Test
    fun `desimal koma diterima`() {
        val points = FrParser.parse("100,0\t-2,3\t0,0\n200,0\t1,5\t0,0\n")
        assertEquals(2, points.size)
        assertEquals(-2.3, points[0].db, 1e-9)
        assertEquals(1.5, points[1].db, 1e-9)
    }

    @Test
    fun `merge L dan R dirata-rata`() {
        val left = FrParser.parse("100\t0.0\n1000\t10.0\n10000\t0.0\n")
        val right = FrParser.parse("100\t2.0\n1000\t12.0\n10000\t2.0\n")
        val merged = FrParser.mergeChannels(left, right)
        assertEquals(3, merged.size)
        assertEquals(1.0, merged[0].db, 1e-9)
        assertEquals(11.0, merged[1].db, 1e-9)
        assertEquals(1.0, merged[2].db, 1e-9)
    }

    @Test
    fun `merge satu channel dipakai apa adanya`() {
        val left = FrParser.parse("100\t3.0\n1000\t4.0\n")
        assertEquals(left, FrParser.mergeChannels(left, null))
        assertEquals(left, FrParser.mergeChannels(left, emptyList()))
        assertEquals(left, FrParser.mergeChannels(null, left))
    }

    @Test
    fun `merge frekuensi beda diinterpolasi`() {
        val left = FrParser.parse("100\t0.0\n1000\t0.0\n")
        val right = FrParser.parse("200\t10.0\n2000\t10.0\n")
        val merged = FrParser.mergeChannels(left, right)
        // Pada 100 Hz: L=0, R diinterpolasi (clamp tepi) = 10 -> rata-rata 5.
        val at100 = merged.first { it.freqHz == 100.0 }
        assertEquals(5.0, at100.db, 1e-9)
    }

    @Test
    fun `interpolasi log-linear`() {
        val points = FrParser.parse("100\t0.0\n1000\t10.0\n")
        // Titik tengah log antara 100 dan 1000 adalah ~316 Hz -> 5 dB.
        assertEquals(5.0, FrParser.interpolateDb(points, 316.22776601683794), 1e-6)
        // Clamp di luar rentang.
        assertEquals(0.0, FrParser.interpolateDb(points, 20.0), 1e-9)
        assertEquals(10.0, FrParser.interpolateDb(points, 20000.0), 1e-9)
    }
}
