package com.srmusic.autoeq

import java.nio.file.Files
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PeqProfileStoreTest {

    private fun sampleProfile() = PeqProfile(
        iemName = "7Hz Eternal",
        source = "Harpo",
        rig = "711",
        targetName = "harman_in-ear_2019",
        preampDb = -3.25,
        filters = listOf(
            ParametricFilter(FilterKind.LOW_SHELF, 31.0, 4.2, 1.0),
            ParametricFilter(FilterKind.PEAKING, 1000.0, -2.5, 1.0),
            ParametricFilter(FilterKind.HIGH_SHELF, 16000.0, 1.0, 1.0),
        ),
    )

    @Test
    fun `round trip save load`() {
        val dir = Files.createTempDirectory("peq-store").toFile()
        try {
            val store = PeqProfileStore(dir)
            store.save("usb:dac-ku", "7hz-eternal", sampleProfile())
            val loaded = store.load("usb:dac-ku", "7hz-eternal")
            assertEquals(sampleProfile(), loaded)
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `load yang tidak ada menghasilkan null`() {
        val dir = Files.createTempDirectory("peq-store").toFile()
        try {
            assertNull(PeqProfileStore(dir).load("usb:x", "tidak-ada"))
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `file rusak menghasilkan null bukan crash`() {
        val dir = Files.createTempDirectory("peq-store").toFile()
        try {
            val store = PeqProfileStore(dir)
            store.fileFor("usb:x", "rusak").apply {
                parentFile?.mkdirs()
                writeText("{ini bukan json", Charsets.UTF_8)
            }
            assertNull(store.load("usb:x", "rusak"))
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `delete dan listSaved`() {
        val dir = Files.createTempDirectory("peq-store").toFile()
        try {
            val store = PeqProfileStore(dir)
            store.save("usb:dac", "iem-a", sampleProfile())
            store.save("bt:headset", "iem-b", sampleProfile())
            assertEquals(2, store.listSaved().size)
            assertTrue(store.delete("usb:dac", "iem-a"))
            assertEquals(1, store.listSaved().size)
            // listSaved mengembalikan kunci yang sudah disanitasi untuk nama file.
            assertEquals("bt_headset" to "iem-b", store.listSaved().single())
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `karakter khusus di nama aman di JSON`() {
        val dir = Files.createTempDirectory("peq-store").toFile()
        try {
            val store = PeqProfileStore(dir)
            val tricky = sampleProfile().copy(iemName = "IEM \"Kutip\" \\ Backslash\nBaru")
            store.save("usb:dac", "tricky", tricky)
            assertEquals(tricky, store.load("usb:dac", "tricky"))
        } finally {
            dir.deleteRecursively()
        }
    }
}
