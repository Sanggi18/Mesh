package com.srmusic.autoeq

import java.io.File
import java.nio.file.Files
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Test client dengan transport palsu (override [SquigLinkClient.httpGet]).
 *
 * Alasan: sandbox VM ini memblokir semua TCP dari proses Java
 * (`other_tcp` = Deny) — bahkan ke localhost — sehingga server HTTP lokal
 * tidak bisa dipakai dari test JVM di sini. Transport asli (HttpURLConnection)
 * adalah wrapper tipis yang endpoint-nya sudah diverifikasi live dengan
 * curl pada 2026-11-20; yang di-test di sini adalah konstruksi URL,
 * parsing JSON, gabung channel, dan logika cache.
 */
class SquigLinkClientTest {

    private lateinit var cacheDir: File
    private var requestCount = 0

    private val sitesJson = """
        [{"name":"Harpo","username":"harpo","dbs":[{"type":"IEMs","folder":"/"}]},
         {"name":"Jaytiss","username":"jaytiss","dbs":[{"type":"IEMs","folder":"/"},{"type":"Headphones","folder":"/headphones/"}]}]
    """.trimIndent()

    private val phoneBookJson = """
        [{"name":"7Hz","phones":[
          {"name":"Eternal","file":"7Hz Eternal","reviewScore":"4","price":"$100"},
          {"name":"Castor","file":["KZ Castor Black DDUU","KZ Castor Black UUUU"]}
        ]}]
    """.trimIndent()

    private val frL = "* Measurement data measured by REW V5.20.5\n" +
        "* Freq(Hz)\tSPL(dB)\tPhase(degrees)\n" +
        "20.0\t80.0\t0.0\n100.0\t82.0\t0.0\n1000.0\t90.0\t0.0\n10000.0\t85.0\t0.0\n"

    private val frR = "* Measurement data measured by REW V5.20.5\n" +
        "* Freq(Hz)\tSPL(dB)\tPhase(degrees)\n" +
        "20.0\t84.0\t0.0\n100.0\t84.0\t0.0\n1000.0\t92.0\t0.0\n10000.0\t87.0\t0.0\n"

    @Before
    fun setUp() {
        cacheDir = Files.createTempDirectory("squig-test").toFile()
        requestCount = 0
    }

    @After
    fun tearDown() {
        cacheDir.deleteRecursively()
    }

    /** Client dengan transport palsu: URL yang dikenal dijawab fixture, sisanya 404. */
    private fun client() = object : SquigLinkClient(cacheDir = cacheDir) {
        override fun httpGet(url: String): String {
            requestCount++
            return when {
                url.endsWith("/squigsites.json") -> sitesJson
                url.endsWith("/data/phone_book.json") -> phoneBookJson
                url.endsWith("7Hz%20Eternal%20L.txt") -> frL
                url.endsWith("7Hz%20Eternal%20R.txt") -> frR
                else -> throw SquigLinkException("HTTP 404 untuk $url")
            }
        }

        override fun siteBaseUrl(site: SquigSite): String = "https://test.invalid"
    }

    private val harpo = SquigSite("Harpo", "harpo", listOf(SquigDb("IEMs", "/")))
    private val iems = SquigDb("IEMs", "/")

    @Test
    fun `fetchSites memparse daftar reviewer`() {
        val sites = client().fetchSites()
        assertEquals(2, sites.size)
        assertEquals("Harpo", sites[0].name)
        assertEquals("harpo", sites[0].username)
        assertEquals(listOf(SquigDb("IEMs", "/")), sites[0].dbs)
        assertEquals(2, sites[1].dbs.size)
        assertEquals("/headphones/", sites[1].dbs[1].folder)
    }

    @Test
    fun `fetchPhoneBook memparse file string dan list`() {
        val sections = client().fetchPhoneBook(harpo, iems)
        assertEquals(1, sections.size)
        assertEquals("7Hz", sections[0].name)
        assertEquals(2, sections[0].phones.size)
        assertEquals(listOf("7Hz Eternal"), sections[0].phones[0].files)
        assertEquals("4", sections[0].phones[0].reviewScore)
        // field `file` berbentuk list -> semua varian terbaca.
        assertEquals(
            listOf("KZ Castor Black DDUU", "KZ Castor Black UUUU"),
            sections[0].phones[1].files,
        )
    }

    @Test
    fun `fetchFr menggabung L dan R`() {
        val result = client().fetchFr(harpo, iems, "7Hz Eternal")
        assertEquals(setOf("L", "R"), result.channels)
        assertEquals(4, result.response.points.size)
        // Rata-rata: (80+84)/2 = 82 di 20 Hz, (90+92)/2 = 91 di 1 kHz.
        assertEquals(82.0, result.response.points[0].db, 1e-9)
        assertEquals(91.0, result.response.points[2].db, 1e-9)
    }

    @Test
    fun `fetchFr file tidak ada melempar SquigLinkException`() {
        var threw = false
        try {
            client().fetchFr(harpo, iems, "Tidak Ada")
        } catch (_: SquigLinkException) {
            threw = true
        }
        assertTrue(threw)
    }

    @Test
    fun `cache 24 jam mencegah fetch ulang`() {
        val c = client()
        requestCount = 0
        c.fetchSites()
        c.fetchSites()
        assertEquals("sites.json harus di-cache", 1, requestCount)
        c.fetchPhoneBook(harpo, iems)
        c.fetchPhoneBook(harpo, iems)
        assertEquals("phone_book harus di-cache", 2, requestCount)
    }

    @Test
    fun `konstruksi URL sesuai pola crawler AutoEq`() {
        val c = client()
        assertEquals("https://squig.link/squigsites.json", c.sitesUrl())
        assertEquals(
            "https://test.invalid/data/phone_book.json",
            c.phoneBookUrl(harpo, iems),
        )
        assertEquals(
            "https://test.invalid/data/7Hz%20Eternal%20L.txt",
            c.frUrl(harpo, iems, "7Hz Eternal", "L"),
        )
        // Folder headphone: /headphones/data/...
        assertEquals(
            "https://test.invalid/headphones/data/phone_book.json",
            c.phoneBookUrl(harpo, SquigDb("Headphones", "/headphones/")),
        )
    }
}
