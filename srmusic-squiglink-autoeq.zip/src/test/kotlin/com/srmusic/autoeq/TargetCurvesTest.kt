package com.srmusic.autoeq

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TargetCurvesTest {

    private fun assetText(relative: String): String {
        // Test dijalankan dari root modul (lihat build.sh).
        val file = File("src/main/assets/$relative")
        require(file.isFile) { "asset tidak ditemukan: ${file.absolutePath}" }
        return file.readText()
    }

    @Test
    fun `Harman IE 2019 dari AutoEq`() {
        val curve = TargetCurves.parse(
            TargetCurves.HARMAN_IN_EAR_2019,
            assetText("targets/harman_in-ear_2019.csv"),
        )
        assertEquals(695, curve.points.size)
        assertEquals(20.0, curve.points.first().freqHz, 0.01)
        assertTrue(curve.points.last().freqHz > 19000.0)
        // Target Harman IE 2019: bass naik ~+7 dB di 20 Hz, turun ke ~-20 dB di 20 kHz.
        assertTrue(curve.points.first().db > 5.0)
        assertTrue(curve.points.last().db < -15.0)
    }

    @Test
    fun `Super 22 dari squiglink`() {
        val curve = TargetCurves.parse(
            TargetCurves.SUPER_22,
            assetText("targets/super_22.csv"),
        )
        assertEquals(481, curve.points.size)
        assertEquals(20.0, curve.points.first().freqHz, 0.01)
        assertEquals(20000.0, curve.points.last().freqHz, 0.01)
    }

    @Test
    fun `loadBuiltIn memakai readAsset`() {
        val loaded = TargetCurves.loadBuiltIn(TargetCurves.HARMAN_IN_EAR_2019) { asset ->
            File("src/main/assets/$asset").takeIf { it.isFile }?.readText()
        }
        assertTrue(loaded != null)
        assertEquals(TargetCurves.HARMAN_IN_EAR_2019, loaded!!.name)
        assertEquals(695, loaded.points.size)
        assertEquals(null, TargetCurves.loadBuiltIn("tidak-ada") { null })
    }
}
