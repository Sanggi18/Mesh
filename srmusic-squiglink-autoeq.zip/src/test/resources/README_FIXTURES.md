# Fixture test (data asli, bukan sintetik)

## `7hz_eternal_R.txt`
- Sumber: https://harpo.squig.link/data/7Hz%20Eternal%20R.txt
- Diambil live 2026-11-20 (HTTP 200, 14.251 byte).
- IEM 7Hz Eternal, diukur Harpo (rig 711), format REW V5.20.5.
- Hanya channel R yang tersedia di server untuk IEM ini (file `L.txt`
  mengembalikan 404) — ini sengaja: menguji jalur single-channel.
- Lisensi data: CC BY 4.0 (squig.link).

## Target CSV
File target TIDAK diduplikasi di sini — test membaca langsung dari
`src/main/assets/targets/` (dijalankan dari root modul, lihat `build.sh`).
